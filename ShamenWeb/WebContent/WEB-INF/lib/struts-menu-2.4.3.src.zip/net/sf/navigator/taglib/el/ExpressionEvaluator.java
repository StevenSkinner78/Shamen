/*    */ package net.sf.navigator.taglib.el;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionEvaluator
/*    */ {
/*    */   private PageContext context;
/*    */   private Tag tag;
/*    */   
/*    */   public ExpressionEvaluator(Tag tag, PageContext context)
/*    */   {
/* 24 */     this.tag = tag;
/* 25 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object eval(String attrName, String attrValue, Class returnClass)
/*    */     throws JspException
/*    */   {
/* 37 */     Object result = null;
/*    */     
/* 39 */     if (attrValue != null) {
/* 40 */       result = ExpressionEvaluatorManager.evaluate(attrName, attrValue, returnClass, this.tag, this.context);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 45 */     return result;
/*    */   }
/*    */   
/*    */   public String evalString(String attrName, String attrValue) throws JspException
/*    */   {
/* 50 */     return (String)eval(attrName, attrValue, String.class);
/*    */   }
/*    */   
/*    */   public boolean evalBoolean(String attrName, String attrValue) throws JspException
/*    */   {
/* 55 */     Boolean rtn = (Boolean)eval(attrName, attrValue, Boolean.class);
/*    */     
/* 57 */     if (rtn != null) {
/* 58 */       return rtn.booleanValue();
/*    */     }
/* 60 */     return false;
/*    */   }
/*    */   
/*    */   public long evalLong(String attrName, String attrValue)
/*    */     throws JspException
/*    */   {
/* 66 */     Long rtn = (Long)eval(attrName, attrValue, Long.class);
/*    */     
/* 68 */     if (rtn != null) {
/* 69 */       return rtn.longValue();
/*    */     }
/* 71 */     return -1L;
/*    */   }
/*    */   
/*    */   public int evalInt(String attrName, String attrValue)
/*    */     throws JspException
/*    */   {
/* 77 */     Integer rtn = (Integer)eval(attrName, attrValue, Integer.class);
/*    */     
/* 79 */     if (rtn != null) {
/* 80 */       return rtn.intValue();
/*    */     }
/* 82 */     return -1;
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\taglib\el\ExpressionEvaluator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */