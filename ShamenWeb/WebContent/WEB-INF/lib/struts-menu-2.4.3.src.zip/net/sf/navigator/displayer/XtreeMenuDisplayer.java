/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XtreeMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*  30 */   private static MessageFormat newWebFXTreeMessage = new MessageFormat("var {0} = new WebFXTree(''{2}'');");
/*  31 */   private static MessageFormat newWebFXTreeItemMessage = new MessageFormat("var {0} = new WebFXTreeItem(''{2}'');");
/*  32 */   private static MessageFormat newWebFXTreeItemMessage1 = new MessageFormat("var {0} = new WebFXTreeItem(''{2}'',''{3}'');");
/*  33 */   private static MessageFormat addMessage = new MessageFormat("{1}.add({0});");
/*  34 */   private static MessageFormat writeMessage = new MessageFormat("document.write({0});");
/*  35 */   private static String parent = "";
/*     */   
/*     */   private static final String END_STATEMENT_START = "document.write(";
/*     */   
/*     */   private static final String END_STATEMENT_END = ");";
/*     */   private static final String TAB = "    ";
/*     */   private static final String SCRIPT_START = "\n<script type=\"text/javascript\">\n<!--";
/*     */   private static final String SCRIPT_END = "//-->\n</script>\n";
/*     */   
/*     */   public void init(PageContext context, MenuDisplayerMapping mapping)
/*     */   {
/*  46 */     super.init(context, mapping);
/*     */     try
/*     */     {
/*  49 */       this.out.print("\n<script type=\"text/javascript\">\n<!--");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public void display(MenuComponent menu) throws JspException, IOException {
/*  55 */     StringBuffer sb = new StringBuffer();
/*  56 */     buildMenuString(menu, sb, isAllowed(menu));
/*  57 */     this.out.print("\n    " + sb);
/*  58 */     this.out.print("    document.write(" + parent + ");");
/*     */   }
/*     */   
/*     */   public void end(PageContext context) {
/*     */     try {
/*  63 */       this.out.print("//-->\n</script>\n");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   protected void buildMenuString(MenuComponent menu, StringBuffer sb, boolean allowed) {
/*  69 */     if (allowed) {
/*  70 */       String[] args = getArgs(menu);
/*  71 */       if ((args[1] == null) || (args[1].equals(""))) {
/*  72 */         sb.append(newWebFXTreeMessage.format(args) + "\n" + "    " + "    ");
/*  73 */         parent = args[0];
/*  74 */       } else if ((args[3] == null) || (args[3].equals(""))) {
/*  75 */         sb.append(newWebFXTreeItemMessage.format(args) + "\n" + "    " + "    ");
/*  76 */         sb.append(addMessage.format(args) + "\n" + "    " + "    ");
/*     */       } else {
/*  78 */         sb.append(newWebFXTreeItemMessage1.format(args) + "\n" + "    " + "    ");
/*  79 */         sb.append(addMessage.format(args) + "\n" + "    " + "    ");
/*     */       }
/*     */       
/*  82 */       MenuComponent[] subMenus = menu.getMenuComponents();
/*     */       
/*  84 */       if (subMenus.length > 0) {
/*  85 */         for (int i = 0; i < subMenus.length; i++) {
/*  86 */           buildMenuString(subMenus[i], sb, allowed ? isAllowed(subMenus[i]) : allowed);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String[] getArgs(MenuComponent menu) {
/*  93 */     String[] args = new String[4];
/*  94 */     args[0] = menu.getName();
/*  95 */     args[1] = getParentName(menu);
/*  96 */     args[2] = getMessage(menu.getTitle());
/*  97 */     args[3] = (menu.getUrl() == null ? "" : menu.getUrl());
/*     */     
/*  99 */     return args;
/*     */   }
/*     */   
/*     */   protected String getParentName(MenuComponent menu) {
/* 103 */     String name = null;
/*     */     
/* 105 */     if (menu.getParent() == null) {
/* 106 */       name = "";
/*     */     } else {
/* 108 */       name = menu.getParent().getName();
/*     */     }
/*     */     
/* 111 */     return name;
/*     */   }
/*     */   
/*     */   protected String getTarget(MenuComponent menu) {
/* 115 */     String theTarget = super.getTarget(menu);
/*     */     
/* 117 */     if (theTarget == null) {
/* 118 */       theTarget = "";
/*     */     }
/*     */     
/* 121 */     return theTarget;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\XtreeMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */