/*     */ package net.sf.navigator.taglib;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import net.sf.navigator.displayer.MenuDisplayer;
/*     */ import net.sf.navigator.displayer.MenuDisplayerMapping;
/*     */ import net.sf.navigator.displayer.MessageResourcesMenuDisplayer;
/*     */ import net.sf.navigator.menu.MenuRepository;
/*     */ import net.sf.navigator.menu.PermissionsAdapter;
/*     */ import net.sf.navigator.menu.RolesPermissionsAdapter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UseMenuDisplayerTag
/*     */   extends TagSupport
/*     */ {
/*  33 */   private static Log log = LogFactory.getLog(UseMenuDisplayerTag.class);
/*     */   
/*     */   public static final String PRIVATE_REPOSITORY = "net.sf.navigator.repositoryKey";
/*     */   public static final String DISPLAYER_KEY = "net.sf.navigator.taglib.DISPLAYER";
/*     */   public static final String ROLES_ADAPTER = "rolesAdapter";
/*     */   public static final String MENU_ID = "net.sf.navigator.MENU_ID";
/*  39 */   protected static ResourceBundle messages = ResourceBundle.getBundle("net.sf.navigator.taglib.LocalStrings");
/*     */   
/*     */   protected MenuDisplayer menuDisplayer;
/*     */   
/*     */   protected String localeKey;
/*     */   
/*     */   protected String name;
/*     */   
/*     */   protected String bundleKey;
/*     */   protected String id;
/*  49 */   private String config = "net.sf.navigator.displayer.DisplayerStrings";
/*     */   
/*     */   private String permissions;
/*     */   
/*     */   private String repository;
/*     */   protected ResourceBundle rb;
/*     */   
/*     */   public String getBundle()
/*     */   {
/*  58 */     return this.bundleKey;
/*     */   }
/*     */   
/*     */   public void setBundle(String bundle) {
/*  62 */     this.bundleKey = bundle;
/*     */   }
/*     */   
/*     */   public String getConfig() {
/*  66 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setConfig(String config) {
/*  70 */     if (log.isDebugEnabled()) {
/*  71 */       log.debug("setting config to: " + config);
/*     */     }
/*     */     
/*  74 */     this.config = config;
/*     */   }
/*     */   
/*     */   public String getLocale() {
/*  78 */     return this.localeKey;
/*     */   }
/*     */   
/*     */   public void setLocale(String locale) {
/*  82 */     this.localeKey = locale;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  86 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  90 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setId(String id) {
/*  94 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getRepository() {
/*  98 */     return this.repository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRepository(String repository)
/*     */   {
/* 109 */     this.repository = repository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPermissions()
/*     */   {
/* 116 */     return this.permissions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPermissions(String permissions)
/*     */   {
/* 123 */     this.permissions = permissions;
/*     */   }
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 127 */     if (this.repository == null) {
/* 128 */       this.repository = "net.sf.navigator.menu.MENU_REPOSITORY";
/*     */     }
/*     */     
/* 131 */     if (log.isDebugEnabled()) {
/* 132 */       log.debug("Looking for repository named '" + this.repository + "'");
/*     */     }
/*     */     
/*     */ 
/* 136 */     MenuRepository rep = (MenuRepository)this.pageContext.findAttribute(this.repository);
/*     */     
/*     */ 
/* 139 */     if (rep == null) {
/* 140 */       throw new JspException(messages.getString("menurepository.not.found"));
/*     */     }
/*     */     
/*     */ 
/* 144 */     if (log.isDebugEnabled()) {
/* 145 */       log.debug("stuffing repository into pageContext...");
/*     */     }
/* 147 */     this.pageContext.setAttribute("net.sf.navigator.repositoryKey", rep);
/*     */     
/*     */ 
/*     */ 
/* 151 */     MenuDisplayerMapping displayerMapping = rep.getMenuDisplayerMapping(this.name);
/*     */     
/*     */ 
/* 154 */     if (displayerMapping == null) {
/* 155 */       throw new JspException(messages.getString("displayer.mapping.not.found"));
/*     */     }
/*     */     
/* 158 */     PermissionsAdapter permissions = getPermissionsAdapter();
/*     */     
/*     */     MenuDisplayer displayerInstance;
/*     */     
/*     */     try
/*     */     {
/* 164 */       displayerInstance = (MenuDisplayer)Class.forName(displayerMapping.getType()).newInstance();
/*     */       
/*     */ 
/* 167 */       this.menuDisplayer = displayerInstance;
/*     */       
/* 169 */       if (displayerMapping.getConfig() != null)
/*     */       {
/* 171 */         setConfig(displayerMapping.getConfig());
/*     */       }
/*     */     } catch (Exception e) {
/* 174 */       throw new JspException(e.getMessage());
/*     */     }
/*     */     
/* 177 */     if (this.bundleKey == null) {
/* 178 */       this.bundleKey = "org.apache.struts.action.MESSAGE";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     if ((this.bundleKey != null) && (!"".equals(this.bundleKey)) && ((displayerInstance instanceof MessageResourcesMenuDisplayer)))
/*     */     {
/* 187 */       MessageResourcesMenuDisplayer mrDisplayerInstance = (MessageResourcesMenuDisplayer)displayerInstance;
/*     */       
/*     */       Locale locale;
/*     */       
/* 191 */       if (this.localeKey == null)
/*     */       {
/* 193 */         Locale locale = (Locale)this.pageContext.findAttribute("org.apache.struts.action.LOCALE");
/*     */         
/* 195 */         if (locale == null) {
/* 196 */           locale = this.pageContext.getRequest().getLocale();
/*     */         }
/*     */       } else {
/* 199 */         locale = (Locale)this.pageContext.findAttribute(this.localeKey);
/*     */       }
/* 201 */       mrDisplayerInstance.setLocale(locale);
/*     */       
/* 203 */       if (this.rb != null) {
/* 204 */         mrDisplayerInstance.setMessageResources(this.rb);
/*     */       } else {
/* 206 */         Object resources = this.pageContext.findAttribute(this.bundleKey);
/*     */         
/* 208 */         if (resources == null) {
/*     */           try
/*     */           {
/* 211 */             this.rb = ResourceBundle.getBundle(this.bundleKey, locale);
/* 212 */             mrDisplayerInstance.setMessageResources(this.rb);
/*     */           } catch (MissingResourceException mre) {
/* 214 */             log.error(mre.getMessage());
/*     */           }
/*     */         } else {
/* 217 */           mrDisplayerInstance.setMessageResources(resources);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 222 */     displayerInstance.setConfig(this.config);
/* 223 */     if (this.id != null) {
/* 224 */       this.pageContext.setAttribute("menuId", this.id);
/*     */     }
/*     */     
/* 227 */     displayerInstance.init(this.pageContext, displayerMapping);
/* 228 */     displayerInstance.setPermissionsAdapter(permissions);
/*     */     
/* 230 */     this.pageContext.setAttribute("net.sf.navigator.taglib.DISPLAYER", displayerInstance);
/*     */     
/* 232 */     return 1;
/*     */   }
/*     */   
/*     */   protected PermissionsAdapter getPermissionsAdapter() throws JspException
/*     */   {
/* 237 */     PermissionsAdapter adapter = null;
/*     */     
/* 239 */     if (this.permissions != null)
/*     */     {
/* 241 */       if (this.permissions.equalsIgnoreCase("rolesAdapter")) {
/* 242 */         adapter = new RolesPermissionsAdapter((HttpServletRequest)this.pageContext.getRequest());
/*     */       }
/*     */       else {
/* 245 */         adapter = (PermissionsAdapter)this.pageContext.findAttribute(this.permissions);
/*     */         
/*     */ 
/* 248 */         if (adapter == null) {
/* 249 */           throw new JspException(messages.getString("permissions.not.found"));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 254 */     return adapter;
/*     */   }
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 258 */     this.menuDisplayer.end(this.pageContext);
/* 259 */     this.pageContext.removeAttribute("net.sf.navigator.taglib.DISPLAYER");
/* 260 */     this.pageContext.removeAttribute("net.sf.navigator.repositoryKey");
/* 261 */     return 6;
/*     */   }
/*     */   
/*     */   public void release() {
/* 265 */     if (log.isDebugEnabled()) {
/* 266 */       log.debug("release() called");
/*     */     }
/*     */     
/* 269 */     this.menuDisplayer = null;
/* 270 */     this.bundleKey = null;
/* 271 */     this.config = "net.sf.navigator.displayer.DisplayerStrings";
/* 272 */     this.localeKey = null;
/* 273 */     this.name = null;
/* 274 */     this.menuDisplayer = null;
/* 275 */     this.repository = null;
/* 276 */     this.permissions = null;
/* 277 */     this.rb = null;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\taglib\UseMenuDisplayerTag.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */