/*    */ package net.sf.navigator.taglib.el;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import net.sf.navigator.menu.MenuComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisplayMenuTag
/*    */   extends net.sf.navigator.taglib.DisplayMenuTag
/*    */ {
/*    */   private String name;
/*    */   private String target;
/*    */   
/*    */   public void setName(String name)
/*    */   {
/* 21 */     this.name = name;
/*    */   }
/*    */   
/*    */   public void setTarget(String target) {
/* 25 */     this.target = target;
/*    */   }
/*    */   
/*    */   public DisplayMenuTag()
/*    */   {
/* 30 */     init();
/*    */   }
/*    */   
/*    */   private void init() {
/* 34 */     this.name = null;
/* 35 */     this.target = null;
/*    */   }
/*    */   
/*    */   public void release() {
/* 39 */     super.release();
/* 40 */     init();
/*    */   }
/*    */   
/*    */   public int doStartTag() throws JspException {
/* 44 */     evaluateExpressions();
/* 45 */     return super.doStartTag();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setPageLocation(MenuComponent menu)
/*    */     throws MalformedURLException, JspException
/*    */   {
/* 57 */     setLocation(menu);
/* 58 */     String url = menu.getLocation();
/*    */     
/* 60 */     if (url != null) {
/* 61 */       ExpressionEvaluator eval = new ExpressionEvaluator(this, this.pageContext);
/* 62 */       menu.setUrl(eval.evalString("url", url));
/*    */     }
/*    */     
/*    */ 
/* 66 */     MenuComponent[] subMenus = menu.getMenuComponents();
/*    */     
/* 68 */     if (subMenus.length > 0) {
/* 69 */       for (int i = 0; i < subMenus.length; i++) {
/* 70 */         setPageLocation(subMenus[i]);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private void evaluateExpressions() throws JspException {
/* 76 */     ExpressionEvaluator eval = new ExpressionEvaluator(this, this.pageContext);
/*    */     
/* 78 */     if (this.name != null) {
/* 79 */       super.setName(eval.evalString("name", this.name));
/*    */     }
/*    */     
/* 82 */     if (this.target != null) {
/* 83 */       super.setTarget(eval.evalString("target", this.target));
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\taglib\el\DisplayMenuTag.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */