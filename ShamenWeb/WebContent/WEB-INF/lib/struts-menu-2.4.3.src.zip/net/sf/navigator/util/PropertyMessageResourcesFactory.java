/*    */ package net.sf.navigator.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyMessageResourcesFactory
/*    */   extends MessageResourcesFactory
/*    */ {
/*    */   public MessageResources createResources(String config)
/*    */   {
/* 47 */     return new PropertyMessageResources(this, config, this.returnNull);
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\util\PropertyMessageResourcesFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */