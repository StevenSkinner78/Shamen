/*     */ package net.sf.navigator.taglib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import net.sf.navigator.displayer.MenuDisplayer;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.menu.MenuRepository;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.struts.taglib.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayMenuTag
/*     */   extends TagSupport
/*     */ {
/*  51 */   protected static final Log log = LogFactory.getLog(DisplayMenuTag.class);
/*     */   private String name;
/*     */   private String target;
/*     */   
/*     */   public void setName(String name)
/*     */   {
/*  57 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setTarget(String target) {
/*  61 */     this.target = target;
/*     */   }
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  65 */     MenuDisplayer displayer = (MenuDisplayer)this.pageContext.getAttribute("net.sf.navigator.taglib.DISPLAYER");
/*     */     
/*     */ 
/*  68 */     if (displayer == null) {
/*  69 */       throw new JspException("Could not retrieve the menu displayer.");
/*     */     }
/*     */     
/*     */ 
/*  73 */     MenuRepository repository = (MenuRepository)this.pageContext.getAttribute("net.sf.navigator.repositoryKey");
/*     */     
/*     */ 
/*  76 */     if (repository == null) {
/*  77 */       throw new JspException("Could not obtain the menu repository");
/*     */     }
/*     */     
/*  80 */     MenuComponent menu = repository.getMenu(this.name);
/*     */     
/*  82 */     if (menu != null)
/*     */     {
/*     */       try {
/*  85 */         if (this.target != null) {
/*  86 */           displayer.setTarget(this.target);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/*  93 */           setPageLocation(menu);
/*     */         } catch (MalformedURLException m) {
/*  95 */           log.error("Incorrect action or forward: " + m.getMessage());
/*  96 */           log.warn("Menu '" + menu.getName() + "' location set to #");
/*  97 */           menu.setLocation("#");
/*     */         }
/*     */         
/* 100 */         displayer.display(menu);
/* 101 */         displayer.setTarget(null);
/*     */       }
/*     */       catch (Exception e) {
/* 104 */         e.printStackTrace();
/* 105 */         throw new JspException(e);
/*     */       }
/*     */     } else {
/* 108 */       String error = UseMenuDisplayerTag.messages.getString("menu.not.found") + " " + this.name;
/*     */       
/* 110 */       log.warn(error);
/*     */       try {
/* 112 */         this.pageContext.getOut().write(error);
/*     */       } catch (IOException io) {
/* 114 */         throw new JspException(error);
/*     */       }
/*     */     }
/*     */     
/* 118 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setPageLocation(MenuComponent menu)
/*     */     throws MalformedURLException, JspException
/*     */   {
/* 140 */     HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/* 141 */     setLocation(menu);
/* 142 */     String url = menu.getLocation();
/*     */     
/*     */ 
/* 145 */     if ((url != null) && (url.indexOf("${") > -1)) {
/* 146 */       String queryString = null;
/*     */       
/* 148 */       if (url.indexOf("?") > -1) {
/* 149 */         queryString = url.substring(url.indexOf("?") + 1);
/* 150 */         url = url.substring(0, url.indexOf(queryString));
/*     */       }
/*     */       
/*     */ 
/* 154 */       if (queryString != null) {
/* 155 */         menu.setUrl(url + parseString(queryString, request));
/*     */       }
/*     */       else {
/* 158 */         menu.setUrl(parseString(url, request).toString());
/*     */       }
/*     */     } else {
/* 161 */       menu.setUrl(url);
/*     */     }
/*     */     
/* 164 */     HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/* 165 */     if (menu.getUrl() != null) {
/* 166 */       menu.setUrl(response.encodeURL(menu.getUrl()));
/*     */     }
/*     */     
/*     */ 
/* 170 */     MenuComponent[] subMenus = menu.getMenuComponents();
/*     */     
/* 172 */     if (subMenus.length > 0) {
/* 173 */       for (int i = 0; i < subMenus.length; i++) {
/* 174 */         setPageLocation(subMenus[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setLocation(MenuComponent menu)
/*     */     throws MalformedURLException
/*     */   {
/* 182 */     if (menu.getLocation() == null) {
/*     */       try {
/* 184 */         if (menu.getPage() != null) {
/* 185 */           HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/* 186 */           menu.setLocation(request.getContextPath() + getPage(menu.getPage()));
/* 187 */           HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/* 188 */           menu.setLocation(response.encodeURL(menu.getLocation()));
/* 189 */         } else if (menu.getForward() != null) {
/* 190 */           menu.setLocation(TagUtils.getInstance().computeURL(this.pageContext, menu.getForward(), null, null, null, menu.getModule(), null, null, false));
/*     */         }
/* 192 */         else if (menu.getAction() != null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 197 */           menu.setLocation(TagUtils.getInstance().computeURL(this.pageContext, null, null, null, menu.getAction(), menu.getModule(), null, null, false));
/*     */         }
/*     */       }
/*     */       catch (NoClassDefFoundError e) {
/* 201 */         if (menu.getForward() != null)
/* 202 */           throw new MalformedURLException("forward '" + menu.getForward() + "' invalid - no struts.jar");
/* 203 */         if (menu.getAction() != null) {
/* 204 */           throw new MalformedURLException("action '" + menu.getAction() + "' invalid - no struts.jar");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPage(String page)
/*     */   {
/* 217 */     if (page.startsWith("/")) {
/* 218 */       return page;
/*     */     }
/* 220 */     page = "/" + page;
/*     */     
/*     */ 
/* 223 */     return page;
/*     */   }
/*     */   
/*     */   private StringBuffer parseString(String str, HttpServletRequest request) {
/* 227 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 229 */     while (str.indexOf("${") >= 0) {
/* 230 */       sb.append(str.substring(0, str.indexOf("${")));
/*     */       
/* 232 */       String variable = str.substring(str.indexOf("${") + 2, str.indexOf("}"));
/* 233 */       String value = String.valueOf(this.pageContext.findAttribute(variable));
/*     */       
/* 235 */       if (value == null)
/*     */       {
/* 237 */         value = request.getParameter(variable);
/*     */       }
/*     */       
/*     */ 
/* 241 */       if (value == null) {
/* 242 */         log.warn("Value for '" + variable + "' not found in pageContext or as a request parameter");
/*     */       }
/*     */       
/*     */ 
/* 246 */       sb.append(value);
/* 247 */       str = str.substring(str.indexOf("}") + 1, str.length());
/*     */     }
/*     */     
/* 250 */     return sb.append(str);
/*     */   }
/*     */   
/*     */   public void release() {
/* 254 */     this.name = null;
/* 255 */     this.target = null;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\taglib\DisplayMenuTag.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */