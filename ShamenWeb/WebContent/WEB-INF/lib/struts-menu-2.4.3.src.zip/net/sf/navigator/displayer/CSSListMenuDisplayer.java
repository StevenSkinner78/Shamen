/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSSListMenuDisplayer
/*     */   extends ListMenuDisplayer
/*     */ {
/*     */   public void display(MenuComponent menu)
/*     */     throws JspException, IOException
/*     */   {
/*  17 */     if (isAllowed(menu)) {
/*  18 */       this.out.println(this.displayStrings.getMessage("ccslm.menu.top", hasViewableChildren(menu) ? " class=\"menubar\"" : ""));
/*     */       
/*  20 */       displayComponents(menu, 0);
/*  21 */       this.out.println(this.displayStrings.getMessage("lmd.menu.bottom"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void displayComponents(MenuComponent menu, int level) throws JspException, IOException
/*     */   {
/*  27 */     if (menu.getUrl() == null)
/*     */     {
/*  29 */       menu.setUrl("javascript:void(0)");
/*     */     }
/*  31 */     MenuComponent[] components = menu.getMenuComponents();
/*     */     
/*  33 */     if (components.length > 0)
/*     */     {
/*  35 */       if (components.length == 0) {
/*  36 */         this.out.println(this.displayStrings.getMessage("lmd.menu.item", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*  42 */         this.out.println(this.displayStrings.getMessage("ccslm.menubar.top", menu.getUrl(), getExtra(menu), getMessage(menu.getTitle())));
/*     */         
/*  44 */         if (hasViewableChildren(menu)) {
/*  45 */           this.out.println("\t\t<ul>");
/*     */         }
/*     */       }
/*     */       
/*  49 */       for (int i = 0; i < components.length; i++)
/*     */       {
/*  51 */         if (isAllowed(components[i])) {
/*  52 */           if (components[i].getMenuComponents().length > 0) {
/*  53 */             if (!hasViewableChildren(components[i])) {
/*  54 */               this.out.println("<li>");
/*     */             } else {
/*  56 */               this.out.println("<li class=\"menubar\">");
/*     */             }
/*     */             
/*  59 */             displayComponents(components[i], level + 1);
/*     */             
/*  61 */             this.out.println(hasViewableChildren(components[i]) ? "\t\t</ul>\t</li>\n" : "\t</li>\n");
/*     */           }
/*     */           else {
/*  64 */             this.out.println(this.displayStrings.getMessage("lmd.menu.item", components[i].getUrl(), super.getMenuToolTip(components[i]), getExtra(components[i]), getMessage(components[i].getTitle())));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */       if ((level == 0) && (hasViewableChildren(menu))) {
/*  75 */         this.out.println("</ul>");
/*     */       }
/*     */     }
/*  78 */     else if (menu.getParent() == null) {
/*  79 */       this.out.println(this.displayStrings.getMessage("lmd.menu.standalone", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  85 */       this.out.println(this.displayStrings.getMessage("lmd.menu.item", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean hasViewableChildren(MenuComponent menu)
/*     */   {
/*  95 */     for (int i = 0; i < menu.getMenuComponents().length; i++) {
/*  96 */       if (isAllowed(menu.getMenuComponents()[i])) {
/*  97 */         return true;
/*     */       }
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\CSSListMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */