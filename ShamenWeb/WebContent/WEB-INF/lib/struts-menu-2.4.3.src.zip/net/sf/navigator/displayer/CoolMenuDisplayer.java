/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoolMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*  49 */   private static MessageFormat menuMessage = new MessageFormat("oCMenu.makeMenu(''{0}'',''{1}'',''{2}'',''{3}'',''{4}'','''','''',''{5}'',''{6}'',{7},{8},{9},");
/*     */   
/*     */   private static final String SCRIPT_START = "<script type=\"text/javascript\">\n";
/*     */   
/*     */   private static final String SCRIPT_END = "</script>\n";
/*     */   
/*     */   private static final String END_STATEMENT = "\noCMenu.makeStyle(); oCMenu.construct()\n";
/*     */   
/*     */   private static final String TOP_IMAGE = "cmTopMenuImage";
/*     */   
/*     */   private static final String SUB_IMAGE = "cmSubMenuImage";
/*     */   
/*     */   private static final String BGCOL_ON = "cmBGColorOn";
/*     */   private static final String BGCOL_OFF = "cmBGColorOff";
/*     */   private static final String TXTCOL = "cmTxtColor";
/*     */   private static final String HOVER = "cmHoverColor";
/*     */   private static final String DIS_BGCOL_ON = "cmDisBGColorOn";
/*     */   private static final String DIS_BGCOL_OFF = "cmDisBGColorOff";
/*     */   private static final String DIS_TXTCOL = "cmDisTxtColor";
/*     */   private static final String DIS_HOVER = "cmDisHoverColor";
/*     */   
/*     */   public void init(PageContext context, MenuDisplayerMapping mapping)
/*     */   {
/*  72 */     super.init(context, mapping);
/*     */     try
/*     */     {
/*  75 */       this.out.print("<script type=\"text/javascript\">\n");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */   public void display(MenuComponent menu)
/*     */     throws JspException, IOException
/*     */   {
/*  84 */     StringBuffer sb = new StringBuffer();
/*  85 */     buildMenuString(menu, sb, isAllowed(menu));
/*  86 */     this.out.print(sb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void end(PageContext context)
/*     */   {
/*     */     try
/*     */     {
/*  95 */       this.out.print("\noCMenu.makeStyle(); oCMenu.construct()\n");
/*  96 */       this.out.print("</script>\n");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   protected void buildMenuString(MenuComponent menu, StringBuffer sb, boolean allowed) {
/* 102 */     sb.append(menuMessage.format(getArgs(menu, allowed)));
/* 103 */     sb.append(allowed ? "cmHoverColor" : "cmDisHoverColor");
/* 104 */     sb.append(",'");
/* 105 */     sb.append(menu.getOnclick() == null ? "" : menu.getOnclick());
/* 106 */     sb.append("')\n");
/*     */     
/* 108 */     MenuComponent[] subMenus = menu.getMenuComponents();
/*     */     
/* 110 */     if (subMenus.length > 0) {
/* 111 */       for (int i = 0; i < subMenus.length; i++) {
/* 112 */         buildMenuString(subMenus[i], sb, allowed ? isAllowed(subMenus[i]) : allowed);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String[] getArgs(MenuComponent menu, boolean allowed)
/*     */   {
/* 119 */     String[] args = new String[10];
/* 120 */     args[0] = menu.getName();
/* 121 */     args[1] = getParentName(menu);
/* 122 */     args[2] = getTitle(menu);
/* 123 */     args[3] = (allowed ? menu.getUrl() : menu.getUrl() == null ? "" : "");
/*     */     
/*     */ 
/* 126 */     args[4] = getTarget(menu);
/* 127 */     args[5] = "";
/* 128 */     args[6] = "";
/* 129 */     args[7] = (allowed ? "cmBGColorOff" : "cmDisBGColorOff");
/* 130 */     args[8] = (allowed ? "cmBGColorOn" : "cmDisBGColorOn");
/* 131 */     args[9] = (allowed ? "cmTxtColor" : "cmDisTxtColor");
/*     */     
/* 133 */     return args;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getTitle(MenuComponent menu)
/*     */   {
/* 143 */     boolean hasSubMenus = false;
/* 144 */     String title = getMessage(menu.getTitle());
/*     */     
/* 146 */     if (menu.getMenuComponents().length > 0) {
/* 147 */       hasSubMenus = true;
/*     */       
/* 149 */       if (menu.getParent() == null) {
/* 150 */         title = title + "'+" + "cmTopMenuImage" + "+'";
/*     */       } else {
/* 152 */         title = title + "'+" + "cmSubMenuImage" + "+'";
/*     */       }
/*     */     }
/*     */     
/* 156 */     return title;
/*     */   }
/*     */   
/*     */   protected String getParentName(MenuComponent menu) {
/* 160 */     String name = null;
/*     */     
/* 162 */     if (menu.getParent() == null) {
/* 163 */       name = "";
/*     */     } else {
/* 165 */       name = menu.getParent().getName();
/*     */     }
/*     */     
/* 168 */     return name;
/*     */   }
/*     */   
/*     */   protected String getTarget(MenuComponent menu) {
/* 172 */     String theTarget = super.getTarget(menu);
/*     */     
/* 174 */     if (theTarget == null) {
/* 175 */       theTarget = "";
/*     */     }
/*     */     
/* 178 */     return theTarget;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\CoolMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */