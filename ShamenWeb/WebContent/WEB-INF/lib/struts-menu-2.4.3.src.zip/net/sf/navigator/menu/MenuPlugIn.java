/*    */ package net.sf.navigator.menu;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import net.sf.navigator.util.LoadableResourceException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.struts.action.ActionServlet;
/*    */ import org.apache.struts.action.PlugIn;
/*    */ import org.apache.struts.config.ModuleConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuPlugIn
/*    */   implements PlugIn
/*    */ {
/* 31 */   private static Log log = LogFactory.getLog(MenuPlugIn.class);
/*    */   private MenuRepository repository;
/* 33 */   private String menuConfig = "/WEB-INF/menu-config.xml";
/*    */   
/*    */   private HttpServlet servlet;
/*    */   
/*    */   public String getMenuConfig()
/*    */   {
/* 39 */     return this.menuConfig;
/*    */   }
/*    */   
/*    */   public void setMenuConfig(String menuConfig) {
/* 43 */     this.menuConfig = menuConfig;
/*    */   }
/*    */   
/*    */   public void init(ActionServlet servlet, ModuleConfig config) throws ServletException
/*    */   {
/* 48 */     if (log.isDebugEnabled()) {
/* 49 */       log.debug("Starting struts-menu initialization");
/*    */     }
/*    */     
/* 52 */     this.servlet = servlet;
/* 53 */     this.repository = new MenuRepository();
/* 54 */     this.repository.setLoadParam(this.menuConfig);
/* 55 */     this.repository.setServletContext(servlet.getServletContext());
/*    */     try
/*    */     {
/* 58 */       this.repository.load();
/* 59 */       servlet.getServletContext().setAttribute("net.sf.navigator.menu.MENU_REPOSITORY", this.repository);
/*    */       
/* 61 */       if (log.isDebugEnabled()) {
/* 62 */         log.debug("struts-menu initialization successful");
/*    */       }
/*    */     } catch (LoadableResourceException lre) {
/* 65 */       throw new ServletException("Failure initializing struts-menu: " + lre.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   public void destroy()
/*    */   {
/* 71 */     this.repository = null;
/* 72 */     this.servlet.getServletContext().removeAttribute("net.sf.navigator.menu.MENU_REPOSITORY");
/* 73 */     this.menuConfig = null;
/* 74 */     this.servlet = null;
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuPlugIn.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */