/*     */ package net.sf.navigator.menu;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuComponent
/*     */   extends MenuBase
/*     */   implements Serializable, Component
/*     */ {
/*  26 */   protected static MenuComponent[] _menuComponent = new MenuComponent[0];
/*     */   
/*     */ 
/*     */ 
/*  30 */   protected List menuComponents = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */   protected MenuComponent parentMenu;
/*     */   private boolean last;
/*     */   private String breadCrumb;
/*     */   
/*     */   public void addMenuComponent(MenuComponent menuComponent)
/*     */   {
/*  38 */     if ((menuComponent.getName() == null) || (menuComponent.getName().equals(""))) {
/*  39 */       menuComponent.setName(this.name + this.menuComponents.size());
/*     */     }
/*     */     
/*  42 */     if (!this.menuComponents.contains(menuComponent)) {
/*  43 */       this.menuComponents.add(menuComponent);
/*  44 */       menuComponent.setParent(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public MenuComponent[] getMenuComponents() {
/*  49 */     return (MenuComponent[])this.menuComponents.toArray(_menuComponent);
/*     */   }
/*     */   
/*     */   public void setMenuComponents(MenuComponent[] menuComponents) {
/*  53 */     for (int i = 0; i < menuComponents.length; i++) {
/*  54 */       MenuComponent component = menuComponents[i];
/*  55 */       this.menuComponents.add(component);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setParent(MenuComponent parentMenu) {
/*  60 */     if (parentMenu != null)
/*     */     {
/*  62 */       if (!parentMenu.getComponents().contains(this)) {
/*  63 */         parentMenu.addMenuComponent(this);
/*     */       }
/*     */     }
/*  66 */     this.parentMenu = parentMenu;
/*     */   }
/*     */   
/*     */   public MenuComponent getParent() {
/*  70 */     return this.parentMenu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getComponents()
/*     */   {
/*  78 */     return this.menuComponents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  87 */     if (!(o instanceof MenuComponent)) {
/*  88 */       return false;
/*     */     }
/*  90 */     MenuComponent m = (MenuComponent)o;
/*     */     
/*  92 */     return (StringUtils.equals(m.getAction(), this.action)) && (StringUtils.equals(m.getAlign(), this.align)) && (StringUtils.equals(m.getAltImage(), this.altImage)) && (StringUtils.equals(m.getDescription(), this.description)) && (StringUtils.equals(m.getForward(), this.forward)) && (StringUtils.equals(m.getHeight(), this.height)) && (StringUtils.equals(m.getImage(), this.image)) && (StringUtils.equals(m.getLocation(), this.location)) && (StringUtils.equals(m.getName(), this.name)) && (StringUtils.equals(m.getOnclick(), this.onclick)) && (StringUtils.equals(m.getOndblclick(), this.ondblclick)) && (StringUtils.equals(m.getOnmouseout(), this.onmouseout)) && (StringUtils.equals(m.getOnmouseover(), this.onmouseover)) && (StringUtils.equals(m.getOnContextMenu(), this.onContextMenu)) && (StringUtils.equals(m.getPage(), this.page)) && (StringUtils.equals(m.getRoles(), this.roles)) && (StringUtils.equals(m.getTarget(), this.target)) && (StringUtils.equals(m.getTitle(), this.title)) && (StringUtils.equals(m.getToolTip(), this.toolTip)) && (StringUtils.equals(m.getWidth(), this.width)) && (StringUtils.equals(m.getModule(), this.module));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMenuDepth()
/*     */   {
/* 121 */     return getMenuDepth(this, 0);
/*     */   }
/*     */   
/*     */   private int getMenuDepth(MenuComponent menu, int currentDepth) {
/* 125 */     int depth = currentDepth + 1;
/*     */     
/* 127 */     MenuComponent[] subMenus = menu.getMenuComponents();
/* 128 */     if (subMenus != null) {
/* 129 */       for (int a = 0; a < subMenus.length; a++) {
/* 130 */         int depthx = getMenuDepth(subMenus[a], currentDepth + 1);
/* 131 */         if (depth < depthx) {
/* 132 */           depth = depthx;
/*     */         }
/*     */       }
/*     */     }
/* 136 */     return depth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLast()
/*     */   {
/* 145 */     return this.last;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLast(boolean last)
/*     */   {
/* 154 */     this.last = last;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeChildren()
/*     */   {
/* 161 */     for (Iterator iterator = getComponents().iterator(); iterator.hasNext();) {
/* 162 */       MenuComponent child = (MenuComponent)iterator.next();
/* 163 */       child.setParent(null);
/* 164 */       iterator.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBreadCrumb() {
/* 169 */     return this.breadCrumb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setBreadCrumb(String delimiter)
/*     */   {
/* 178 */     if (getParent() == null) {
/* 179 */       this.breadCrumb = this.name;
/* 180 */       setChildBreadCrumb(delimiter);
/*     */     } else {
/* 182 */       MenuComponent parent = getParent();
/* 183 */       this.breadCrumb = (parent.getBreadCrumb() + delimiter + this.name);
/* 184 */       setChildBreadCrumb(delimiter);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setChildBreadCrumb(String delimiter) {
/* 189 */     List children = getComponents();
/* 190 */     for (Iterator iterator = children.iterator(); iterator.hasNext();) {
/* 191 */       MenuComponent child = (MenuComponent)iterator.next();
/* 192 */       child.setBreadCrumb(delimiter);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 197 */     return "name: " + this.name;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuComponent.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */