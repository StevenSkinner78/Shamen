/*    */ package net.sf.navigator.displayer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import net.sf.navigator.menu.MenuComponent;
/*    */ import net.sf.navigator.util.MessageResources;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TabbedMenuDisplayer
/*    */   extends ListMenuDisplayer
/*    */ {
/*    */   public void display(MenuComponent menu)
/*    */     throws JspException, IOException
/*    */   {
/* 19 */     if (isAllowed(menu)) {
/* 20 */       displayComponents(menu, 0);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void displayComponents(MenuComponent menu, int level) throws JspException, IOException
/*    */   {
/* 26 */     MenuComponent[] components = menu.getMenuComponents();
/*    */     
/* 28 */     if (components.length > 0) {
/* 29 */       this.out.print("\t<li>");
/*    */       
/* 31 */       String menuClass = "submenu";
/*    */       
/* 33 */       if (level >= 1) {
/* 34 */         menuClass = "deepmenu";
/*    */       }
/*    */       
/* 37 */       if (menu.getUrl() == null) {
/* 38 */         this.log.info("The Menu '" + getMessage(menu.getTitle()) + "' does not have a location defined, using first submenu's location");
/*    */         
/* 40 */         menu.setUrl(components[0].getUrl());
/*    */       }
/*    */       
/* 43 */       this.out.print(this.displayStrings.getMessage("tmd.menu.tab", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*    */       
/*    */ 
/*    */ 
/* 47 */       for (int i = 0; i < components.length; i++)
/*    */       {
/* 49 */         if (isAllowed(components[i])) {
/* 50 */           if (components[i].getMenuComponents().length > 0)
/*    */           {
/* 52 */             if (menuClass.equals("submenu")) {
/* 53 */               this.out.print("<li>");
/*    */             }
/*    */             
/* 56 */             displayComponents(components[i], level + 1);
/*    */             
/* 58 */             this.out.println("</ul></li>");
/*    */             
/* 60 */             if (i == components[i].getMenuComponents().length - 1) {
/* 61 */               this.out.println("</li>");
/*    */             }
/*    */           } else {
/* 64 */             this.out.println(this.displayStrings.getMessage("tmd.menu.item", components[i].getUrl(), super.getMenuToolTip(components[i]), super.getExtra(components[i]), getMessage(components[i].getTitle())));
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 74 */       if (menuClass.equals("submenu")) {
/* 75 */         this.out.println("\t</ul>");
/*    */       }
/*    */       
/* 78 */       this.out.print("\t</li>");
/*    */     } else {
/* 80 */       this.out.println(this.displayStrings.getMessage("tmd.menu.item", menu.getUrl(), super.getMenuToolTip(menu), super.getExtra(menu), getMessage(menu.getTitle())));
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\TabbedMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */