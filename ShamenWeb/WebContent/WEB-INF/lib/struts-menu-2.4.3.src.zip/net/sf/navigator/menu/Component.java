package net.sf.navigator.menu;

public abstract interface Component
{
  public abstract String getName();
  
  public abstract void setName(String paramString);
}


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\Component.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */