package net.sf.navigator.util;

import javax.servlet.ServletContext;

public abstract interface LoadableResource
{
  public abstract void setLoadParam(String paramString);
  
  public abstract String getLoadParam();
  
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract void load()
    throws LoadableResourceException;
  
  public abstract void reload()
    throws LoadableResourceException;
  
  public abstract ServletContext getServletContext();
  
  public abstract void setServletContext(ServletContext paramServletContext);
}


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\util\LoadableResource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */