/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*     */   protected static final String nbsp = "&nbsp;";
/*     */   
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/*  28 */     super.init(pageContext, mapping);
/*     */     try
/*     */     {
/*  31 */       this.out.println(this.displayStrings.getMessage("smd.style"));
/*     */     } catch (Exception e) {
/*  33 */       this.log.error(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public void display(MenuComponent menu) throws JspException, IOException {
/*  38 */     if (isAllowed(menu)) {
/*  39 */       this.out.println(this.displayStrings.getMessage("smd.menu.top"));
/*  40 */       displayComponents(menu, 0);
/*  41 */       this.out.println(this.displayStrings.getMessage("smd.menu.bottom"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void displayComponents(MenuComponent menu, int level) throws JspException, IOException
/*     */   {
/*  47 */     MenuComponent[] components = menu.getMenuComponents();
/*     */     
/*  49 */     if (components.length > 0) {
/*  50 */       this.out.println(this.displayStrings.getMessage("smd.menu.item.top", getSpace(level) + this.displayStrings.getMessage("smd.menu.item.image.bullet") + getMessage(menu.getTitle())));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  55 */       for (int i = 0; i < components.length; i++) {
/*  56 */         if (components[i].getMenuComponents().length > 0) {
/*  57 */           if (isAllowed(components[i])) {
/*  58 */             displayComponents(components[i], level + 1);
/*     */           }
/*     */         }
/*  61 */         else if (isAllowed(components[i])) {
/*  62 */           this.out.println(this.displayStrings.getMessage("smd.menu.item", components[i].getUrl(), super.getMenuTarget(components[i]), super.getMenuToolTip(components[i]), getSpace(level + 1) + getImage(components[i]) + getMessage(components[i].getTitle())));
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  72 */       this.out.println(this.displayStrings.getMessage("smd.menu.item", menu.getUrl(), super.getMenuTarget(menu), super.getMenuToolTip(menu), getSpace(level) + getImage(menu) + getMessage(menu.getTitle())));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getSpace(int length)
/*     */   {
/*  81 */     String space = "";
/*     */     
/*  83 */     for (int i = 0; i < length; i++) {
/*  84 */       space = space + "&nbsp;" + "&nbsp;";
/*     */     }
/*     */     
/*  87 */     return space;
/*     */   }
/*     */   
/*     */   protected String getImage(MenuComponent menu) {
/*     */     String imageTag;
/*     */     String imageTag;
/*  93 */     if ((menu.getImage() == null) || (menu.getImage().equals(""))) {
/*  94 */       imageTag = "";
/*     */     } else {
/*  96 */       imageTag = this.displayStrings.getMessage("smd.menu.item.image", menu.getImage(), super.getMenuToolTip(menu));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 101 */     return imageTag;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\SimpleMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */