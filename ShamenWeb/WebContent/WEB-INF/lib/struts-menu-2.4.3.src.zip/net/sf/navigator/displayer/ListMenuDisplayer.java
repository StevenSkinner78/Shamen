/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/*  27 */     super.init(pageContext, mapping);
/*  28 */     String id = (String)pageContext.getAttribute("menuId");
/*     */     try
/*     */     {
/*  31 */       this.out.println(this.displayStrings.getMessage("lmd.begin", id != null ? "id=\"" + id + "\" " : ""));
/*     */     }
/*     */     catch (Exception e) {
/*  34 */       this.log.error(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public void display(MenuComponent menu) throws JspException, IOException {
/*  39 */     if (isAllowed(menu)) {
/*  40 */       this.out.println(this.displayStrings.getMessage("lmd.menu.top"));
/*  41 */       displayComponents(menu, 0);
/*  42 */       this.out.println(this.displayStrings.getMessage("lmd.menu.bottom"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void displayComponents(MenuComponent menu, int level) throws JspException, IOException
/*     */   {
/*  48 */     MenuComponent[] components = menu.getMenuComponents();
/*     */     
/*  50 */     if (components.length > 0)
/*     */     {
/*  52 */       String domId = StringUtils.deleteWhitespace(getMessage(menu.getName()));
/*     */       
/*  54 */       domId = domId + (int)(1000.0D * Math.random());
/*     */       
/*  56 */       String menuClass = "menu";
/*     */       
/*  58 */       if (level >= 1) {
/*  59 */         menuClass = "submenu";
/*     */       }
/*     */       
/*     */ 
/*  63 */       if (menu.getUrl() != null) {
/*  64 */         this.out.println(this.displayStrings.getMessage("lmd.menu.actuator.link", domId, getMessage(menu.getTitle()), menuClass, getMessage(menu.getUrl())));
/*     */       }
/*     */       else
/*     */       {
/*  68 */         this.out.println(this.displayStrings.getMessage("lmd.menu.actuator.top", domId, getMessage(menu.getTitle()), menuClass));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  74 */       for (int i = 0; i < components.length; i++)
/*     */       {
/*  76 */         if (isAllowed(components[i])) {
/*  77 */           if (components[i].getMenuComponents().length > 0) {
/*  78 */             this.out.println("<li>");
/*     */             
/*  80 */             displayComponents(components[i], level + 1);
/*     */             
/*  82 */             this.out.println(this.displayStrings.getMessage("lmd.menu.actuator.bottom"));
/*     */           } else {
/*  84 */             this.out.println(this.displayStrings.getMessage("lmd.menu.item", components[i].getUrl(), super.getMenuToolTip(components[i]), getExtra(components[i]), getMessage(components[i].getTitle())));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */       if (menuClass.equals("menu")) {
/*  95 */         this.out.println("</ul>");
/*     */       }
/*     */     }
/*  98 */     else if (menu.getParent() == null) {
/*  99 */       this.out.println(this.displayStrings.getMessage("lmd.menu.standalone", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 105 */       this.out.println(this.displayStrings.getMessage("lmd.menu.item", menu.getUrl(), super.getMenuToolTip(menu), getExtra(menu), getMessage(menu.getTitle())));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void end(PageContext context)
/*     */   {
/*     */     try
/*     */     {
/* 120 */       this.out.print(this.displayStrings.getMessage("lmd.end"));
/*     */     } catch (Exception e) {
/* 122 */       this.log.error(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getExtra(MenuComponent menu) {
/* 127 */     StringBuffer extra = new StringBuffer();
/* 128 */     if (menu.getTarget() != null) {
/* 129 */       extra.append(" target=\"").append(menu.getTarget()).append("\"");
/*     */     }
/* 131 */     if (menu.getOnclick() != null) {
/* 132 */       extra.append(" onclick=\"").append(menu.getOnclick()).append("\"");
/*     */     }
/* 134 */     if (menu.getOnmouseover() != null) {
/* 135 */       extra.append(" onmouseover=\"").append(menu.getOnmouseover()).append("\"");
/*     */     }
/* 137 */     if (menu.getOnmouseout() != null) {
/* 138 */       extra.append(" onmouseout=\"").append(menu.getOnmouseout()).append("\"");
/*     */     }
/* 140 */     if (menu.getWidth() != null) {
/* 141 */       extra.append(" style=\"width: " + menu.getWidth() + "px\"");
/*     */     }
/* 143 */     return extra.length() > 0 ? extra.toString() : "";
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\ListMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */