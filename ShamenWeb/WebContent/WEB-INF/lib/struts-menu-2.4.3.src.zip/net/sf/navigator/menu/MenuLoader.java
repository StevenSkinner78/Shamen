/*    */ package net.sf.navigator.menu;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import net.sf.navigator.util.LoadableResourceException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationContextException;
/*    */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuLoader
/*    */   extends WebApplicationObjectSupport
/*    */ {
/* 28 */   private static Log log = LogFactory.getLog(MenuLoader.class);
/*    */   
/*    */ 
/* 31 */   private String menuConfig = "/WEB-INF/menu-config.xml";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMenuConfig(String menuConfig)
/*    */   {
/* 38 */     this.menuConfig = menuConfig;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void initApplicationContext()
/*    */     throws ApplicationContextException
/*    */   {
/*    */     try
/*    */     {
/* 47 */       if (log.isDebugEnabled()) {
/* 48 */         log.debug("Starting struts-menu initialization");
/*    */       }
/*    */       
/* 51 */       MenuRepository repository = new MenuRepository();
/* 52 */       repository.setLoadParam(this.menuConfig);
/* 53 */       repository.setServletContext(getServletContext());
/*    */       try
/*    */       {
/* 56 */         repository.load();
/* 57 */         getServletContext().setAttribute("net.sf.navigator.menu.MENU_REPOSITORY", repository);
/*    */         
/* 59 */         if (log.isDebugEnabled()) {
/* 60 */           log.debug("struts-menu initialization successful");
/*    */         }
/*    */       } catch (LoadableResourceException lre) {
/* 63 */         throw new ServletException("Failure initializing struts-menu: " + lre.getMessage());
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 67 */       throw new ApplicationContextException("Failed to initialize Struts Menu repository", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuLoader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */