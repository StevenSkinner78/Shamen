/*     */ package net.sf.navigator.menu;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MenuBase
/*     */   implements Component
/*     */ {
/*     */   protected String action;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String align;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String altImage;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String description;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String forward;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String height;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String image;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String location;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String name;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String onclick;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String ondblclick;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String onmouseout;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String onmouseover;
/*     */   
/*     */ 
/*     */   protected String page;
/*     */   
/*     */ 
/*     */   protected String roles;
/*     */   
/*     */ 
/*     */   protected String target;
/*     */   
/*     */ 
/*     */   protected String title;
/*     */   
/*     */ 
/*     */   protected String toolTip;
/*     */   
/*     */ 
/*     */   protected String width;
/*     */   
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */   protected String onContextMenu;
/*     */   
/*     */ 
/*     */   protected String module;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAction(String action)
/*     */   {
/*  90 */     this.action = action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAction()
/*     */   {
/*  98 */     return this.action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlign()
/*     */   {
/* 106 */     return this.align;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlign(String align)
/*     */   {
/* 114 */     this.align = align;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAltImage(String altImage)
/*     */   {
/* 121 */     this.altImage = altImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAltImage()
/*     */   {
/* 128 */     return this.altImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 135 */     this.description = description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 142 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForward(String forward)
/*     */   {
/* 150 */     this.forward = forward;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getForward()
/*     */   {
/* 157 */     return this.forward;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHeight(String height)
/*     */   {
/* 164 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getHeight()
/*     */   {
/* 171 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setImage(String image)
/*     */   {
/* 178 */     this.image = image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getImage()
/*     */   {
/* 185 */     return this.image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLocation(String location)
/*     */   {
/* 192 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLocation()
/*     */   {
/* 199 */     return this.location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 206 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 213 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOnclick(String onclick)
/*     */   {
/* 220 */     this.onclick = onclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getOnclick()
/*     */   {
/* 227 */     return this.onclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOnmouseout(String onmouseout)
/*     */   {
/* 234 */     this.onmouseout = onmouseout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getOnmouseout()
/*     */   {
/* 241 */     return this.onmouseout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOnmouseover(String onmouseover)
/*     */   {
/* 248 */     this.onmouseover = onmouseover;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getOnmouseover()
/*     */   {
/* 255 */     return this.onmouseover;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPage(String page)
/*     */   {
/* 263 */     this.page = page;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPage()
/*     */   {
/* 271 */     return this.page;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoles(String roles)
/*     */   {
/* 279 */     this.roles = roles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRoles()
/*     */   {
/* 287 */     return this.roles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTarget(String target)
/*     */   {
/* 294 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTarget()
/*     */   {
/* 301 */     return this.target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 308 */     this.title = title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 315 */     return this.title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setToolTip(String toolTip)
/*     */   {
/* 322 */     this.toolTip = toolTip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getToolTip()
/*     */   {
/* 329 */     return this.toolTip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUrl(String url)
/*     */   {
/* 336 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 343 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 351 */     this.width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 358 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getOnContextMenu()
/*     */   {
/* 364 */     return this.onContextMenu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOnContextMenu(String string)
/*     */   {
/* 371 */     this.onContextMenu = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOndblclick()
/*     */   {
/* 379 */     return this.ondblclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOndblclick(String ondblclick)
/*     */   {
/* 387 */     this.ondblclick = ondblclick;
/*     */   }
/*     */   
/*     */   public String getModule() {
/* 391 */     return this.module;
/*     */   }
/*     */   
/*     */   public void setModule(String module) {
/* 395 */     this.module = module;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuBase.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */