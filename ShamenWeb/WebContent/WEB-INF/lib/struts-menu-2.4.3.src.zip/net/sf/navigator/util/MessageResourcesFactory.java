/*     */ package net.sf.navigator.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageResourcesFactory
/*     */   implements Serializable
/*     */ {
/*  56 */   protected boolean returnNull = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getReturnNull()
/*     */   {
/*  65 */     return this.returnNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturnNull(boolean returnNull)
/*     */   {
/*  74 */     this.returnNull = returnNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   protected static transient Class clazz = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private static Log LOG = LogFactory.getLog(MessageResourcesFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   protected static String factoryClass = "net.sf.navigator.util.PropertyMessageResourcesFactory";
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract MessageResources createResources(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getFactoryClass()
/*     */   {
/* 120 */     return factoryClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setFactoryClass(String factoryClass)
/*     */   {
/* 130 */     factoryClass = factoryClass;
/* 131 */     clazz = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageResourcesFactory createFactory()
/*     */   {
/*     */     try
/*     */     {
/* 148 */       if (clazz == null)
/* 149 */         clazz = Class.forName(factoryClass);
/* 150 */       return (MessageResourcesFactory)clazz.newInstance();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 154 */       LOG.error("MessageResourcesFactory.createFactory", t); }
/* 155 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\util\MessageResourcesFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */