/*     */ package net.sf.navigator.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyMessageResources
/*     */   extends MessageResources
/*     */ {
/*     */   public PropertyMessageResources(MessageResourcesFactory factory, String config)
/*     */   {
/*  65 */     super(factory, config);
/*  66 */     log.trace("Initializing, config='" + config + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyMessageResources(MessageResourcesFactory factory, String config, boolean returnNull)
/*     */   {
/*  82 */     super(factory, config, returnNull);
/*  83 */     log.trace("Initializing, config='" + config + "', returnNull=" + returnNull);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected HashMap locales = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected static final Log log = LogFactory.getLog(PropertyMessageResources.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   protected HashMap messages = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key)
/*     */   {
/* 132 */     if (log.isDebugEnabled()) {
/* 133 */       log.debug("getMessage(" + locale + "," + key + ")");
/*     */     }
/*     */     
/*     */ 
/* 137 */     String localeKey = localeKey(locale);
/* 138 */     String originalKey = messageKey(localeKey, key);
/* 139 */     String messageKey = null;
/* 140 */     String message = null;
/* 141 */     int underscore = 0;
/* 142 */     boolean addIt = false;
/*     */     
/*     */ 
/*     */ 
/*     */     for (;;)
/*     */     {
/* 148 */       loadLocale(localeKey);
/*     */       
/*     */ 
/* 151 */       messageKey = messageKey(localeKey, key);
/* 152 */       synchronized (this.messages) {
/* 153 */         message = (String)this.messages.get(messageKey);
/* 154 */         if (message != null) {
/* 155 */           if (addIt) {
/* 156 */             this.messages.put(originalKey, message);
/*     */           }
/* 158 */           return message;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 163 */       addIt = true;
/* 164 */       underscore = localeKey.lastIndexOf("_");
/* 165 */       if (underscore < 0) {
/*     */         break;
/*     */       }
/* 168 */       localeKey = localeKey.substring(0, underscore);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 173 */     if (!this.defaultLocale.equals(locale)) {
/* 174 */       localeKey = localeKey(this.defaultLocale);
/* 175 */       messageKey = messageKey(localeKey, key);
/* 176 */       loadLocale(localeKey);
/* 177 */       synchronized (this.messages) {
/* 178 */         message = (String)this.messages.get(messageKey);
/* 179 */         if (message != null) {
/* 180 */           this.messages.put(originalKey, message);
/* 181 */           return message;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 187 */     localeKey = "";
/* 188 */     messageKey = messageKey(localeKey, key);
/* 189 */     loadLocale(localeKey);
/* 190 */     synchronized (this.messages) {
/* 191 */       message = (String)this.messages.get(messageKey);
/* 192 */       if (message != null) {
/* 193 */         this.messages.put(originalKey, message);
/* 194 */         return message;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 199 */     if (this.returnNull) {
/* 200 */       return null;
/*     */     }
/* 202 */     return "???" + messageKey(locale, key) + "???";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void loadLocale(String localeKey)
/*     */   {
/* 224 */     if (log.isTraceEnabled()) {
/* 225 */       log.trace("loadLocale(" + localeKey + ")");
/*     */     }
/*     */     
/*     */ 
/* 229 */     if (this.locales.get(localeKey) != null) {
/* 230 */       return;
/*     */     }
/*     */     
/* 233 */     this.locales.put(localeKey, localeKey);
/*     */     
/*     */ 
/* 236 */     String name = this.config.replace('.', '/');
/* 237 */     if (localeKey.length() > 0) {
/* 238 */       name = name + "_" + localeKey;
/*     */     }
/*     */     
/* 241 */     name = name + ".properties";
/* 242 */     InputStream is = null;
/* 243 */     Properties props = new Properties();
/*     */     
/*     */ 
/* 246 */     if (log.isTraceEnabled()) {
/* 247 */       log.trace("  Loading resource '" + name + "'");
/*     */     }
/*     */     
/* 250 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 251 */     if (classLoader == null) {
/* 252 */       classLoader = getClass().getClassLoader();
/*     */     }
/*     */     
/* 255 */     is = classLoader.getResourceAsStream(name);
/* 256 */     if (is != null) {
/*     */       try {
/* 258 */         props.load(is);
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 264 */           is.close();
/*     */         } catch (IOException e) {
/* 266 */           log.error("loadLocale()", e);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 271 */         if (!log.isTraceEnabled()) {
/*     */           break label330;
/*     */         }
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 261 */         log.error("loadLocale()", e);
/*     */       } finally {
/*     */         try {
/* 264 */           is.close();
/*     */         } catch (IOException e) {
/* 266 */           log.error("loadLocale()", e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 272 */     log.trace("  Loading resource completed");
/*     */     
/*     */     label330:
/*     */     
/* 276 */     if (props.size() < 1) {
/* 277 */       return;
/*     */     }
/*     */     
/* 280 */     synchronized (this.messages) {
/* 281 */       Iterator names = props.keySet().iterator();
/* 282 */       while (names.hasNext()) {
/* 283 */         String key = (String)names.next();
/* 284 */         if (log.isTraceEnabled()) {
/* 285 */           log.trace("  Saving message key '" + messageKey(localeKey, key));
/*     */         }
/* 287 */         this.messages.put(messageKey(localeKey, key), props.getProperty(key));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\util\PropertyMessageResources.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */