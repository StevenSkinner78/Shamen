/*    */ package net.sf.navigator.displayer;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuDisplayerMapping
/*    */   implements Serializable
/*    */ {
/*    */   private String name;
/*    */   private String type;
/*    */   private String config;
/*    */   
/*    */   public String getName()
/*    */   {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 41 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 48 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setType(String type)
/*    */   {
/* 55 */     this.type = type;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getConfig()
/*    */   {
/* 62 */     return this.config;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setConfig(String config)
/*    */   {
/* 69 */     this.config = config;
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\MenuDisplayerMapping.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */