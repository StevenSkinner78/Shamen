/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.menu.PermissionsAdapter;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMenuDisplayer
/*     */   implements MenuDisplayer
/*     */ {
/*  29 */   protected final transient Log log = LogFactory.getLog(getClass());
/*     */   
/*     */   protected String name;
/*     */   
/*     */   protected MessageResources displayStrings;
/*     */   
/*     */   protected JspWriter out;
/*     */   protected String target;
/*     */   protected PermissionsAdapter permissionsAdapter;
/*     */   protected MenuDisplayerMapping mapping;
/*     */   
/*     */   public String getName()
/*     */   {
/*  42 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  46 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getConfig() {
/*  50 */     String config = null;
/*     */     
/*  52 */     if (this.displayStrings != null) {
/*  53 */       config = this.displayStrings.getConfig();
/*     */     }
/*     */     
/*  56 */     return config;
/*     */   }
/*     */   
/*     */   public void setConfig(String config) {
/*  60 */     this.displayStrings = MessageResources.getMessageResources(config);
/*     */   }
/*     */   
/*     */   public String getTarget() {
/*  64 */     return this.target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getTarget(MenuComponent menu)
/*     */   {
/*  75 */     String theTarget = null;
/*     */     
/*  77 */     if (this.target == null) {
/*  78 */       if (menu.getTarget() != null) {
/*  79 */         theTarget = menu.getTarget();
/*     */       }
/*     */     } else {
/*  82 */       theTarget = this.target;
/*     */     }
/*     */     
/*  85 */     return theTarget;
/*     */   }
/*     */   
/*     */   public void setTarget(String target) {
/*  89 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PermissionsAdapter getPermissionsAdapter()
/*     */   {
/*  97 */     return this.permissionsAdapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPermissionsAdapter(PermissionsAdapter permissionsAdapter)
/*     */   {
/* 105 */     this.permissionsAdapter = permissionsAdapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/* 118 */     this.out = pageContext.getOut();
/* 119 */     this.mapping = mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void display(MenuComponent paramMenuComponent)
/*     */     throws JspException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void end(PageContext pageContext) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAllowed(MenuComponent menu)
/*     */   {
/* 137 */     return (this.permissionsAdapter == null) || (this.permissionsAdapter.isAllowed(menu));
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\AbstractMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */