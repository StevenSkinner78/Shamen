package net.sf.navigator.displayer;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import net.sf.navigator.menu.MenuComponent;
import net.sf.navigator.menu.PermissionsAdapter;

public abstract interface MenuDisplayer
{
  public static final String DEFAULT_CONFIG = "net.sf.navigator.displayer.DisplayerStrings";
  public static final String _SELF = "_self";
  public static final String NBSP = "&nbsp;";
  public static final String EMPTY = "";
  
  public abstract void display(MenuComponent paramMenuComponent)
    throws JspException, IOException;
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract String getConfig();
  
  public abstract void setConfig(String paramString);
  
  public abstract String getTarget();
  
  public abstract void setTarget(String paramString);
  
  public abstract void init(PageContext paramPageContext, MenuDisplayerMapping paramMenuDisplayerMapping);
  
  public abstract void end(PageContext paramPageContext);
  
  public abstract PermissionsAdapter getPermissionsAdapter();
  
  public abstract void setPermissionsAdapter(PermissionsAdapter paramPermissionsAdapter);
}


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\MenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */