/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.struts.util.MessageResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageResourcesMenuDisplayer
/*     */   extends AbstractMenuDisplayer
/*     */ {
/*  26 */   protected final transient Log log = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*  30 */   protected Object messages = null;
/*  31 */   protected Locale locale = null;
/*     */   
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/*  36 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/*  40 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public Object getMessageResources() {
/*  44 */     return this.messages;
/*     */   }
/*     */   
/*     */   public void setMessageResources(Object messages) {
/*  48 */     this.messages = messages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key)
/*     */   {
/*  58 */     String message = null;
/*     */     
/*  60 */     if ((this.messages != null) && ((this.messages instanceof ResourceBundle))) {
/*  61 */       if (this.log.isDebugEnabled()) {
/*  62 */         this.log.debug("Looking up string '" + key + "' in ResourceBundle");
/*     */       }
/*  64 */       ResourceBundle bundle = (ResourceBundle)this.messages;
/*     */       try {
/*  66 */         message = bundle.getString(key);
/*     */       } catch (MissingResourceException mre) {
/*  68 */         message = null;
/*     */       }
/*  70 */     } else if (this.messages != null) {
/*  71 */       if (this.log.isDebugEnabled()) {
/*  72 */         this.log.debug("Looking up message '" + key + "' in Struts' MessageResources");
/*     */       }
/*     */       
/*  75 */       if ("org.apache.struts.util.PropertyMessageResources".equals(this.messages.getClass().getName())) {
/*  76 */         MessageResources resources = (MessageResources)this.messages;
/*     */         try {
/*  78 */           if (this.locale != null)
/*     */           {
/*  80 */             message = resources.getMessage(this.locale, key);
/*     */           } else {
/*  82 */             message = resources.getMessage(key);
/*     */           }
/*     */         } catch (Throwable t) {
/*  85 */           message = null;
/*     */         }
/*     */       }
/*     */     } else {
/*  89 */       message = key;
/*     */     }
/*     */     
/*  92 */     if (message == null) {
/*  93 */       message = key;
/*     */     }
/*     */     
/*  96 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getMenuTarget(MenuComponent menu)
/*     */   {
/*     */     String menuTarget;
/*     */     
/*     */ 
/*     */     String menuTarget;
/*     */     
/* 108 */     if (this.target != null) {
/* 109 */       menuTarget = this.target;
/*     */     } else { String menuTarget;
/* 111 */       if (menu.getTarget() != null) {
/* 112 */         menuTarget = menu.getTarget();
/*     */       } else {
/* 114 */         menuTarget = "_self";
/*     */       }
/*     */     }
/*     */     
/* 118 */     return menuTarget;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getMenuToolTip(MenuComponent menu)
/*     */   {
/*     */     String tooltip;
/*     */     
/*     */ 
/*     */     String tooltip;
/*     */     
/* 130 */     if (menu.getToolTip() != null) {
/* 131 */       tooltip = getMessage(menu.getToolTip());
/*     */     } else {
/* 133 */       tooltip = getMessage(menu.getTitle());
/*     */     }
/*     */     
/* 136 */     return tooltip;
/*     */   }
/*     */   
/*     */   public String getMenuOnClick(MenuComponent menu) {
/* 140 */     if (menu.getOnclick() != null) {
/* 141 */       return " onclick=\"" + menu.getOnclick() + "\"";
/*     */     }
/* 143 */     return "";
/*     */   }
/*     */   
/*     */   public abstract void display(MenuComponent paramMenuComponent)
/*     */     throws JspException, IOException;
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\MessageResourcesMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */