/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Calendar;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.app.tools.VelocityFormatter;
/*     */ import org.apache.velocity.tools.view.servlet.ServletLogger;
/*     */ import org.apache.velocity.tools.view.servlet.WebappLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VelocityMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*  33 */   protected static final Log log = LogFactory.getLog(VelocityMenuDisplayer.class);
/*  34 */   private static VelocityEngine velocityEngine = new VelocityEngine();
/*  35 */   private PageContext pageContext = null;
/*     */   
/*     */   public static void initialize(ServletContext context) {
/*  38 */     velocityEngine.setApplicationAttribute(ServletContext.class.getName(), context);
/*     */     
/*     */ 
/*  41 */     velocityEngine.setProperty("runtime.log.logsystem.class", ServletLogger.class.getName());
/*     */     
/*     */ 
/*     */ 
/*  45 */     velocityEngine.setProperty("resource.loader", "webapp");
/*  46 */     velocityEngine.setProperty("webapp.resource.loader.class", WebappLoader.class.getName());
/*     */     
/*     */     try
/*     */     {
/*  50 */       Properties props = new Properties();
/*  51 */       ResourceBundle defaults = ResourceBundle.getBundle("net.sf.navigator.displayer.velocity");
/*  52 */       for (Enumeration keys = defaults.getKeys(); keys.hasMoreElements();) {
/*  53 */         String key = (String)keys.nextElement();
/*  54 */         props.put(key, defaults.getString(key));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  59 */       ResourceBundle custom = null;
/*     */       try
/*     */       {
/*  62 */         custom = ResourceBundle.getBundle("velocity");
/*  63 */         for (keys = custom.getKeys(); keys.hasMoreElements();) {
/*  64 */           String key = (String)keys.nextElement();
/*  65 */           props.put(key, custom.getString(key));
/*     */         }
/*     */       } catch (MissingResourceException mre) { Enumeration keys;
/*  68 */         log.debug("No velocity.properties found in classpath, using default settings");
/*     */       }
/*     */       
/*  71 */       velocityEngine.init(props);
/*     */     } catch (Exception e) {
/*  73 */       log.error("Error initializing Velocity: " + e.getMessage());
/*  74 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/*  81 */     super.init(pageContext, mapping);
/*  82 */     this.pageContext = pageContext;
/*     */   }
/*     */   
/*     */   public void display(MenuComponent menu) throws JspException, IOException {
/*  86 */     if (isAllowed(menu)) {
/*  87 */       displayComponents(menu);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void displayComponents(MenuComponent menu) throws JspException, IOException
/*     */   {
/*  93 */     HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/*     */     Template t;
/*     */     try
/*     */     {
/*  97 */       String template = getConfig();
/*     */       
/*  99 */       if (template == null) {
/* 100 */         throw new JspException("You must specify a template using the 'config' attribute.");
/*     */       }
/* 102 */       log.debug("using template: " + template);
/*     */       
/*     */ 
/* 105 */       t = velocityEngine.getTemplate(template);
/*     */     } catch (Exception e) {
/* 107 */       String msg = "Error initializing Velocity: " + e.toString();
/* 108 */       log.error(msg, e);
/* 109 */       throw new JspException(msg, e);
/*     */     }
/*     */     
/* 112 */     StringWriter sw = new StringWriter();
/* 113 */     VelocityContext context = new VelocityContext();
/*     */     
/* 115 */     context.put("formatter", new VelocityFormatter(context));
/* 116 */     context.put("now", Calendar.getInstance().getTime());
/* 117 */     context.put("ctxPath", request.getContextPath());
/*     */     
/* 119 */     context.put("stringUtils", new StringUtils());
/*     */     
/*     */ 
/* 122 */     context.put("map", new HashMap());
/*     */     
/*     */ 
/* 125 */     if (!StringUtils.isEmpty(this.name)) {
/* 126 */       Object val1 = this.pageContext.findAttribute(this.name);
/*     */       
/* 128 */       if (val1 != null) {
/* 129 */         context.put(this.name, val1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 134 */     Enumeration e = request.getAttributeNames();
/*     */     
/* 136 */     while (e.hasMoreElements()) {
/* 137 */       String name = (String)e.nextElement();
/* 138 */       Object value = request.getAttribute(name);
/* 139 */       context.put(name, value);
/*     */     }
/*     */     
/* 142 */     context.put("request", request);
/* 143 */     context.put("session", request.getSession(false));
/*     */     
/* 145 */     if (this.pageContext.getAttribute("menuId") != null) {
/* 146 */       context.put("menuId", this.pageContext.getAttribute("menuId"));
/*     */     }
/* 148 */     context.put("menu", menu);
/* 149 */     context.put("displayer", this);
/*     */     try
/*     */     {
/* 152 */       t.merge(context, sw);
/*     */     } catch (Exception ex) {
/* 154 */       ex.printStackTrace();
/* 155 */       throw new JspException(ex);
/*     */     }
/*     */     
/* 158 */     String result = sw.getBuffer().toString();
/*     */     
/*     */ 
/* 161 */     this.pageContext.getOut().print(result);
/*     */   }
/*     */   
/*     */   public void end(PageContext context) {
/* 165 */     this.pageContext = null;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\VelocityMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */