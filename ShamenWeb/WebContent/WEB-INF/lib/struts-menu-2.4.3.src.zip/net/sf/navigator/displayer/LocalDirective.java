/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.velocity.context.InternalContextAdapter;
/*     */ import org.apache.velocity.exception.MethodInvocationException;
/*     */ import org.apache.velocity.exception.ParseErrorException;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ import org.apache.velocity.runtime.directive.Directive;
/*     */ import org.apache.velocity.runtime.parser.node.ASTReference;
/*     */ import org.apache.velocity.runtime.parser.node.Node;
/*     */ import org.apache.velocity.runtime.parser.node.SimpleNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDirective
/*     */   extends Directive
/*     */ {
/*     */   public String getName()
/*     */   {
/* 102 */     return "local";
/*     */   }
/*     */   
/*     */   public int getType()
/*     */   {
/* 107 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean render(InternalContextAdapter context, Writer writer, Node node)
/*     */     throws IOException, MethodInvocationException, ResourceNotFoundException, ParseErrorException
/*     */   {
/* 115 */     Map data = new HashMap();
/*     */     
/* 117 */     int num = node.jjtGetNumChildren();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     for (int i = 0; i < num; i++)
/*     */     {
/* 125 */       SimpleNode child = (SimpleNode)node.jjtGetChild(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */       if (child.getType() == 10)
/*     */       {
/* 133 */         child.render(context, writer);
/* 134 */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 140 */       if (child.getType() == 14)
/*     */       {
/* 142 */         data.put(child, child.execute(null, context));
/*     */       }
/*     */       else
/*     */       {
/* 146 */         System.out.println("unhandled type");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 151 */     Iterator it = data.keySet().iterator();
/*     */     
/* 153 */     while (it.hasNext())
/*     */     {
/* 155 */       ASTReference ref = (ASTReference)it.next();
/*     */       
/* 157 */       ref.setValue(context, data.get(ref));
/*     */     }
/*     */     
/* 160 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\LocalDirective.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */