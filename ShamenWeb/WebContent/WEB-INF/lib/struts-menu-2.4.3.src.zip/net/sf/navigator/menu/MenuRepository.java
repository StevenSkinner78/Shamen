/*     */ package net.sf.navigator.menu;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import net.sf.navigator.displayer.MenuDisplayerMapping;
/*     */ import net.sf.navigator.displayer.VelocityMenuDisplayer;
/*     */ import net.sf.navigator.util.LoadableResource;
/*     */ import net.sf.navigator.util.LoadableResourceException;
/*     */ import org.apache.commons.collections.map.LinkedMap;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuRepository
/*     */   implements LoadableResource, Serializable
/*     */ {
/*     */   public static final String MENU_REPOSITORY_KEY = "net.sf.navigator.menu.MENU_REPOSITORY";
/*  31 */   private static Log log = LogFactory.getLog(MenuRepository.class);
/*     */   
/*     */ 
/*     */ 
/*  35 */   protected String config = null;
/*  36 */   protected String name = null;
/*  37 */   protected ServletContext servletContext = null;
/*  38 */   protected LinkedMap menus = new LinkedMap();
/*  39 */   protected LinkedMap displayers = new LinkedMap();
/*  40 */   protected LinkedMap templates = new LinkedMap();
/*     */   private String breadCrumbDelimiter;
/*     */   
/*     */   public Set getMenuNames()
/*     */   {
/*  45 */     return this.menus.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getTopMenus()
/*     */   {
/*  53 */     List topMenus = new ArrayList();
/*  54 */     if (this.menus == null) {
/*  55 */       log.warn("No menus found in repository!");
/*  56 */       return topMenus;
/*     */     }
/*     */     
/*  59 */     for (Iterator it = this.menus.keySet().iterator(); it.hasNext();) {
/*  60 */       String name = (String)it.next();
/*  61 */       MenuComponent menu = getMenu(name);
/*  62 */       if (menu.getParent() == null) {
/*  63 */         topMenus.add(menu);
/*     */       }
/*     */     }
/*  66 */     return topMenus;
/*     */   }
/*     */   
/*     */   public MenuComponent getMenu(String menuName) {
/*  70 */     return (MenuComponent)this.menus.get(menuName);
/*     */   }
/*     */   
/*     */   public MenuDisplayerMapping getMenuDisplayerMapping(String displayerName) {
/*  74 */     return (MenuDisplayerMapping)this.displayers.get(displayerName);
/*     */   }
/*     */   
/*     */   protected Digester initDigester() {
/*  78 */     Digester digester = new Digester();
/*  79 */     digester.setClassLoader(Thread.currentThread().getContextClassLoader());
/*  80 */     digester.push(this);
/*     */     
/*     */ 
/*     */ 
/*  84 */     digester.addObjectCreate("MenuConfig/Menus/Menu", "net.sf.navigator.menu.MenuComponent", "type");
/*  85 */     digester.addSetProperties("MenuConfig/Menus/Menu");
/*  86 */     digester.addSetNext("MenuConfig/Menus/Menu", "addMenu");
/*     */     
/*     */ 
/*  89 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item", "net.sf.navigator.menu.MenuComponent", "type");
/*  90 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item");
/*  91 */     digester.addSetNext("MenuConfig/Menus/Menu/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/*     */ 
/*  94 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item/Item", "net.sf.navigator.menu.MenuComponent", "type");
/*  95 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item/Item");
/*  96 */     digester.addSetNext("MenuConfig/Menus/Menu/Item/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/*     */ 
/*  99 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item/Item/Item", "net.sf.navigator.menu.MenuComponent", "type");
/* 100 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item/Item/Item");
/* 101 */     digester.addSetNext("MenuConfig/Menus/Menu/Item/Item/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/*     */ 
/* 104 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item/Item/Item/Item", "net.sf.navigator.menu.MenuComponent", "type");
/* 105 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item/Item/Item/Item");
/* 106 */     digester.addSetNext("MenuConfig/Menus/Menu/Item/Item/Item/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/*     */ 
/* 109 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item", "net.sf.navigator.menu.MenuComponent", "type");
/* 110 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item");
/* 111 */     digester.addSetNext("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/*     */ 
/* 114 */     digester.addObjectCreate("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item/Item", "net.sf.navigator.menu.MenuComponent", "type");
/* 115 */     digester.addSetProperties("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item/Item");
/* 116 */     digester.addSetNext("MenuConfig/Menus/Menu/Item/Item/Item/Item/Item/Item", "addMenuComponent", "net.sf.navigator.menu.MenuComponent");
/*     */     
/* 118 */     digester.addObjectCreate("MenuConfig/Displayers/Displayer", "net.sf.navigator.displayer.MenuDisplayerMapping", "mapping");
/* 119 */     digester.addSetProperties("MenuConfig/Displayers/Displayer");
/* 120 */     digester.addSetNext("MenuConfig/Displayers/Displayer", "addMenuDisplayerMapping", "net.sf.navigator.displayer.MenuDisplayerMapping");
/* 121 */     digester.addSetProperty("MenuConfig/Displayers/Displayer/SetProperty", "property", "value");
/*     */     
/* 123 */     return digester;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addMenu(MenuComponent menu)
/*     */   {
/*     */     Iterator it;
/*     */     
/* 131 */     if (this.menus.containsKey(menu.getName())) {
/* 132 */       if (log.isDebugEnabled()) {
/* 133 */         log.warn("Menu '" + menu.getName() + "' already exists in repository");
/*     */       }
/* 135 */       List children = getMenu(menu.getName()).getComponents();
/* 136 */       if ((children != null) && (menu.getComponents() != null)) {
/* 137 */         for (it = children.iterator(); it.hasNext();) {
/* 138 */           MenuComponent child = (MenuComponent)it.next();
/* 139 */           menu.addMenuComponent(child);
/*     */         }
/*     */       }
/*     */     }
/* 143 */     this.menus.put(menu.getName(), menu);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMenu(String name)
/*     */   {
/* 151 */     this.menus.remove(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAllMenus()
/*     */   {
/* 159 */     this.menus.clear();
/*     */   }
/*     */   
/*     */   public void addMenuDisplayerMapping(MenuDisplayerMapping displayerMapping) {
/* 163 */     this.displayers.put(displayerMapping.getName(), displayerMapping);
/* 164 */     if (displayerMapping.getType().equals("net.sf.navigator.displayer.VelocityMenuDisplayer")) {
/* 165 */       if (this.servletContext == null) {
/* 166 */         log.error("ServletContext not set - can't initialize Velocity");
/*     */       } else {
/* 168 */         VelocityMenuDisplayer.initialize(this.servletContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkedMap getDisplayers()
/*     */   {
/* 179 */     return this.displayers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplayers(LinkedMap displayers)
/*     */   {
/* 189 */     this.displayers = displayers;
/*     */   }
/*     */   
/*     */   public void load() throws LoadableResourceException {
/* 193 */     if (getServletContext() == null) {
/* 194 */       throw new LoadableResourceException("no reference to servlet context found");
/*     */     }
/*     */     
/* 197 */     InputStream input = null;
/* 198 */     Digester digester = initDigester();
/*     */     try
/*     */     {
/* 201 */       input = getServletContext().getResourceAsStream(this.config);
/* 202 */       digester.parse(input); return;
/*     */     } catch (Exception e) {
/* 204 */       e.printStackTrace();
/* 205 */       throw new LoadableResourceException("Error parsing resource file: " + this.config + " nested exception is: " + e.getMessage());
/*     */     } finally {
/*     */       try {
/* 208 */         input.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public void reload() throws LoadableResourceException {
/* 215 */     this.menus.clear();
/* 216 */     this.displayers.clear();
/* 217 */     load();
/*     */   }
/*     */   
/*     */   public void setLoadParam(String loadParam) {
/* 221 */     this.config = loadParam;
/*     */   }
/*     */   
/*     */   public String getLoadParam() {
/* 225 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 229 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 233 */     return this.name;
/*     */   }
/*     */   
/*     */   public ServletContext getServletContext() {
/* 237 */     return this.servletContext;
/*     */   }
/*     */   
/*     */   public void setServletContext(ServletContext context) {
/* 241 */     this.servletContext = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuComponent getMenu(String menuName, String delimiter)
/*     */   {
/* 251 */     MenuComponent parent = null;
/* 252 */     StringTokenizer st = new StringTokenizer(menuName, delimiter);
/* 253 */     boolean firstMenu = true;
/*     */     
/* 255 */     while (st.hasMoreTokens()) {
/* 256 */       if (firstMenu) {
/* 257 */         parent = getMenu(st.nextToken());
/* 258 */         firstMenu = false;
/*     */       } else {
/* 260 */         MenuComponent child = null;
/* 261 */         String name = st.nextToken();
/* 262 */         for (int a = 0; a < parent.getComponents().size(); a++) {
/* 263 */           if (name.equals(((MenuComponent)parent.getComponents().get(a)).getName())) {
/* 264 */             child = (MenuComponent)parent.getComponents().get(a);
/* 265 */             a = parent.getComponents().size();
/*     */           }
/*     */         }
/* 268 */         if (child != null) {
/* 269 */           parent = child;
/*     */         } else {
/* 271 */           parent = null;
/* 272 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 277 */     return parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMenuDepth(String menuName)
/*     */   {
/* 288 */     MenuComponent menu = getMenu(menuName);
/* 289 */     if (menu == null)
/* 290 */       return -1;
/* 291 */     if (menu.getMenuComponents() == null)
/* 292 */       return 1;
/* 293 */     return menu.getMenuDepth();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMenuDepth()
/*     */   {
/* 302 */     int currentDepth = 0;
/*     */     
/* 304 */     List topMenus = getTopMenus();
/*     */     
/* 306 */     if (topMenus == null)
/* 307 */       return -1;
/* 308 */     for (Iterator menu = topMenus.iterator(); menu.hasNext();) {
/* 309 */       int depth = ((MenuComponent)menu.next()).getMenuDepth();
/* 310 */       if (currentDepth < depth)
/* 311 */         currentDepth = depth;
/*     */     }
/* 313 */     return currentDepth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuComponent[] getTopMenusAsArray()
/*     */   {
/* 321 */     List menuList = getTopMenus();
/* 322 */     MenuComponent[] menus = new MenuComponent[menuList.size()];
/* 323 */     for (int a = 0; a < menuList.size(); a++) {
/* 324 */       menus[a] = ((MenuComponent)menuList.get(a));
/*     */     }
/*     */     
/* 327 */     return menus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getTopMenusNames()
/*     */   {
/* 335 */     List menus = getTopMenus();
/* 336 */     ArrayList names = new ArrayList();
/* 337 */     for (Iterator iterator = menus.iterator(); iterator.hasNext();) {
/* 338 */       MenuComponent menu = (MenuComponent)iterator.next();
/* 339 */       names.add(menu.getName());
/*     */     }
/* 341 */     return names;
/*     */   }
/*     */   
/*     */   public void setBreadCrumbDelimiter(String string) {
/* 345 */     this.breadCrumbDelimiter = string;
/*     */   }
/*     */   
/*     */   public void buildBreadCrumbs() {
/* 349 */     if (this.breadCrumbDelimiter == null) {
/* 350 */       throw new NullPointerException("No breadCrumbDelimiter present");
/*     */     }
/* 352 */     ArrayList menus = (ArrayList)getTopMenus();
/* 353 */     for (Iterator iterator = menus.iterator(); iterator.hasNext();) {
/* 354 */       MenuComponent menu = (MenuComponent)iterator.next();
/* 355 */       menu.setBreadCrumb(this.breadCrumbDelimiter);
/*     */     }
/*     */   }
/*     */   
/*     */   public void buildBreadCrumbs(String delimiter) {
/* 360 */     this.breadCrumbDelimiter = delimiter;
/* 361 */     buildBreadCrumbs();
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuRepository.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */