/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DropDownMenuDisplayer
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/*  25 */     super.init(pageContext, mapping);
/*     */     
/*  27 */     StringBuffer sb = new StringBuffer();
/*     */     
/*     */ 
/*  30 */     sb.append(this.displayStrings.getMessage("smd.style", "{", "}"));
/*     */     
/*     */ 
/*  33 */     sb.append(this.displayStrings.getMessage("dd.js.start"));
/*  34 */     sb.append(this.displayStrings.getMessage("dd.js.image.src.expand", this.displayStrings.getMessage("dd.image.src.expand")));
/*     */     
/*  36 */     sb.append(this.displayStrings.getMessage("dd.js.image.src.expanded", this.displayStrings.getMessage("dd.image.src.expanded")));
/*     */     
/*  38 */     sb.append(this.displayStrings.getMessage("dd.js.toggle.display", "{", "}"));
/*  39 */     sb.append(this.displayStrings.getMessage("dd.js.end"));
/*     */     try
/*     */     {
/*  42 */       this.out.print(sb.toString());
/*     */     } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public void display(MenuComponent menu) throws JspException, IOException {
/*  47 */     String title = super.getMessage(menu.getTitle());
/*  48 */     StringBuffer sb = new StringBuffer();
/*  49 */     String img = "";
/*     */     
/*  51 */     if (menu.getImage() != null) {
/*  52 */       img = this.displayStrings.getMessage("dd.image", menu.getImage());
/*     */     }
/*     */     
/*  55 */     MenuComponent[] components = menu.getMenuComponents();
/*     */     
/*  57 */     sb.append(this.displayStrings.getMessage("dd.menu.top"));
/*     */     
/*  59 */     if (components.length > 0) {
/*  60 */       if (isAllowed(menu)) {
/*  61 */         sb.append(this.displayStrings.getMessage("dd.menu.expander", menu.getName(), menu.getName() + "_img", this.displayStrings.getMessage("dd.image.expander", new StringBuffer().append(menu.getName()).append("_img").toString(), this.displayStrings.getMessage("dd.image.src.expand")) + "&nbsp;" + img + title));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */         displayComponents(menu, sb);
/*  68 */         sb.append(this.displayStrings.getMessage("dd.menu.restore", menu.getName(), menu.getName() + "_img"));
/*     */       }
/*     */       else
/*     */       {
/*  72 */         sb.append(this.displayStrings.getMessage("dd.menu.restricted", menu.getName(), menu.getName() + "_img", this.displayStrings.getMessage("dd.image.expander", new StringBuffer().append(menu.getName()).append("_img").toString(), this.displayStrings.getMessage("dd.image.src.expand")) + "&nbsp;" + img + title));
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  80 */       sb.append(title);
/*     */     }
/*     */     
/*  83 */     sb.append(this.displayStrings.getMessage("dd.menu.bottom"));
/*  84 */     this.out.println(sb.toString());
/*     */   }
/*     */   
/*     */   private void displayComponents(MenuComponent menu, StringBuffer sb) throws JspException, IOException
/*     */   {
/*  89 */     String title = null;
/*  90 */     String name = menu.getName();
/*  91 */     String href = "";
/*  92 */     String img = "";
/*  93 */     MenuComponent[] components = menu.getMenuComponents();
/*     */     
/*  95 */     sb.append(this.displayStrings.getMessage("dd.menu.item.top", name));
/*     */     
/*  97 */     for (int i = 0; i < components.length; i++) {
/*  98 */       title = super.getMessage(components[i].getTitle());
/*     */       
/* 100 */       if (components[i].getImage() != null) {
/* 101 */         img = this.displayStrings.getMessage("dd.image", components[i].getImage());
/*     */       }
/*     */       else {
/* 104 */         img = "";
/*     */       }
/*     */       
/* 107 */       href = components[i].getUrl();
/*     */       
/* 109 */       sb.append(this.displayStrings.getMessage("dd.menu.item.row.start"));
/*     */       
/* 111 */       if (components[i].getMenuComponents().length > 0) {
/* 112 */         if (isAllowed(components[i])) {
/* 113 */           sb.append(this.displayStrings.getMessage("dd.menu.expander", components[i].getName(), components[i].getName() + "_img", this.displayStrings.getMessage("dd.image.expander", new StringBuffer().append(components[i].getName()).append("_img").toString(), this.displayStrings.getMessage("dd.image.src.expand")) + "&nbsp;" + img + title));
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */           displayComponents(components[i], sb);
/* 121 */           sb.append(this.displayStrings.getMessage("dd.menu.restore", components[i].getName(), components[i].getName() + "_img"));
/*     */         }
/*     */         else
/*     */         {
/* 125 */           sb.append(this.displayStrings.getMessage("dd.menu.restricted", components[i].getName(), components[i].getName() + "_img", this.displayStrings.getMessage("dd.image.expander", new StringBuffer().append(components[i].getName()).append("_img").toString(), this.displayStrings.getMessage("dd.image.src.expand")) + "&nbsp;" + img + title));
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 134 */       else if (isAllowed(components[i])) {
/* 135 */         sb.append(this.displayStrings.getMessage("dd.link.start", href, super.getMenuTarget(components[i]), super.getMenuToolTip(components[i])));
/*     */         
/*     */ 
/* 138 */         sb.append("&nbsp;");
/* 139 */         sb.append("&nbsp;");
/* 140 */         sb.append(img);
/* 141 */         sb.append(title);
/* 142 */         sb.append(this.displayStrings.getMessage("dd.link.end"));
/*     */       } else {
/* 144 */         sb.append(this.displayStrings.getMessage("dd.link.restricted", href, super.getMenuTarget(components[i]), super.getMenuToolTip(components[i])));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 150 */       sb.append(this.displayStrings.getMessage("dd.menu.item.row.end"));
/*     */     }
/*     */     
/* 153 */     sb.append(this.displayStrings.getMessage("dd.menu.item.bottom"));
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\DropDownMenuDisplayer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */