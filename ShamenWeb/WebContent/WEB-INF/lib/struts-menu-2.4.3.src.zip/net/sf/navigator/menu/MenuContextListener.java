/*    */ package net.sf.navigator.menu;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import net.sf.navigator.util.LoadableResourceException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuContextListener
/*    */   implements ServletContextListener
/*    */ {
/* 31 */   private static Log log = LogFactory.getLog(MenuContextListener.class);
/*    */   
/*    */   private ServletContext ctx;
/*    */   
/* 35 */   private String menuConfig = "/WEB-INF/menu-config.xml";
/*    */   
/*    */ 
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent sce)
/*    */   {
/* 41 */     this.ctx = sce.getServletContext();
/*    */     
/* 43 */     if (log.isDebugEnabled()) {
/* 44 */       log.debug("Starting struts-menu initialization");
/*    */     }
/*    */     
/*    */ 
/* 48 */     String override = sce.getServletContext().getInitParameter("menuConfigLocation");
/*    */     
/* 50 */     if (override != null) {
/* 51 */       if (log.isDebugEnabled()) {
/* 52 */         log.debug("using menuConfigLocation: " + override);
/*    */       }
/* 54 */       this.menuConfig = override;
/*    */     }
/*    */     
/* 57 */     MenuRepository repository = new MenuRepository();
/* 58 */     repository.setLoadParam(this.menuConfig);
/* 59 */     repository.setServletContext(this.ctx);
/*    */     try
/*    */     {
/* 62 */       repository.load();
/* 63 */       this.ctx.setAttribute("net.sf.navigator.menu.MENU_REPOSITORY", repository);
/*    */       
/* 65 */       if (log.isDebugEnabled()) {
/* 66 */         log.debug("struts-menu initialization successfull");
/*    */       }
/*    */     } catch (LoadableResourceException lre) {
/* 69 */       log.fatal("Failure initializing struts-menu: " + lre.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 74 */     if (log.isDebugEnabled()) {
/* 75 */       log.debug("destroying struts-menu...");
/*    */     }
/*    */     
/* 78 */     sce.getServletContext().removeAttribute("net.sf.navigator.menu.MENU_REPOSITORY");
/* 79 */     this.menuConfig = null;
/* 80 */     this.ctx = null;
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\MenuContextListener.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */