/*     */ package net.sf.navigator.taglib.el;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.BundleSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UseMenuDisplayerTag
/*     */   extends net.sf.navigator.taglib.UseMenuDisplayerTag
/*     */ {
/*     */   private String name;
/*     */   private String bundle;
/*  21 */   private String config = "net.sf.navigator.displayer.DisplayerStrings";
/*     */   private String locale;
/*     */   private String permissions;
/*     */   private String repository;
/*     */   
/*     */   public void setName(String name) {
/*  27 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setBundle(String bundle) {
/*  31 */     this.bundle = bundle;
/*     */   }
/*     */   
/*     */   public void setConfig(String config) {
/*  35 */     this.config = config;
/*     */   }
/*     */   
/*     */   public void setLocale(String locale) {
/*  39 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public void setPermissions(String permissions) {
/*  43 */     this.permissions = permissions;
/*     */   }
/*     */   
/*     */   public void setRepository(String key) {
/*  47 */     this.repository = key;
/*     */   }
/*     */   
/*     */   public UseMenuDisplayerTag()
/*     */   {
/*  52 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  56 */     this.name = null;
/*  57 */     this.bundle = null;
/*  58 */     this.config = null;
/*  59 */     this.locale = null;
/*  60 */     this.permissions = null;
/*  61 */     this.repository = null;
/*     */   }
/*     */   
/*     */   public void release() {
/*  65 */     super.release();
/*  66 */     init();
/*     */   }
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  70 */     evaluateExpressions();
/*     */     
/*     */ 
/*  73 */     Tag tag = findAncestorWithClass(this, BundleSupport.class);
/*     */     
/*  75 */     if (tag != null) {
/*  76 */       BundleSupport parent = (BundleSupport)tag;
/*  77 */       this.rb = parent.getLocalizationContext().getResourceBundle();
/*     */     }
/*     */     else {
/*  80 */       LocalizationContext localization = BundleSupport.getLocalizationContext(this.pageContext);
/*     */       
/*     */ 
/*  83 */       if (localization != null) {
/*  84 */         this.rb = localization.getResourceBundle();
/*     */       }
/*     */     }
/*     */     
/*  88 */     return super.doStartTag();
/*     */   }
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/*  92 */     ExpressionEvaluator eval = new ExpressionEvaluator(this, this.pageContext);
/*     */     
/*  94 */     if (this.name != null) {
/*  95 */       super.setName(eval.evalString("name", this.name));
/*     */     }
/*     */     
/*  98 */     if (this.bundle != null) {
/*  99 */       super.setBundle(eval.evalString("bundle", this.bundle));
/*     */     }
/*     */     
/* 102 */     if (this.config != null) {
/* 103 */       super.setConfig(eval.evalString("config", this.config));
/*     */     }
/*     */     
/* 106 */     if (this.locale != null) {
/* 107 */       super.setLocale(eval.evalString("locale", this.locale));
/*     */     }
/*     */     
/* 110 */     if (this.permissions != null) {
/* 111 */       super.setPermissions(eval.evalString("permissions", this.permissions));
/*     */     }
/*     */     
/* 114 */     if (this.repository != null) {
/* 115 */       super.setRepository(eval.evalString("repository", this.repository));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\taglib\el\UseMenuDisplayerTag.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */