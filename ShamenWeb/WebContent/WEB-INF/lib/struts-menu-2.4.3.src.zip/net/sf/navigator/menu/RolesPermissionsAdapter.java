/*    */ package net.sf.navigator.menu;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RolesPermissionsAdapter
/*    */   implements PermissionsAdapter
/*    */ {
/* 19 */   private Pattern delimiters = Pattern.compile("(?<!\\\\),");
/*    */   private HttpServletRequest request;
/*    */   
/*    */   public RolesPermissionsAdapter(HttpServletRequest request) {
/* 23 */     this.request = request;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isAllowed(MenuComponent menu)
/*    */   {
/* 32 */     if (menu.getRoles() == null) {
/* 33 */       return true;
/*    */     }
/*    */     
/* 36 */     String[] allowedRoles = this.delimiters.split(menu.getRoles());
/* 37 */     for (int i = 0; i < allowedRoles.length; i++) {
/* 38 */       if (this.request.isUserInRole(allowedRoles[i])) {
/* 39 */         return true;
/*    */       }
/*    */     }
/*    */     
/* 43 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\menu\RolesPermissionsAdapter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */