/*     */ package net.sf.navigator.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageResources
/*     */   implements Serializable
/*     */ {
/*  59 */   protected static Log log = LogFactory.getLog(MessageResources.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   protected String config = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConfig()
/*     */   {
/*  71 */     return this.config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   protected Locale defaultLocale = Locale.getDefault();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   protected MessageResourcesFactory factory = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageResourcesFactory getFactory()
/*     */   {
/*  89 */     return this.factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected HashMap formats = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected boolean returnNull = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getReturnNull()
/*     */   {
/* 110 */     return this.returnNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturnNull(boolean returnNull)
/*     */   {
/* 120 */     this.returnNull = returnNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageResources(MessageResourcesFactory factory, String config)
/*     */   {
/* 133 */     this(factory, config, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageResources(MessageResourcesFactory factory, String config, boolean returnNull)
/*     */   {
/* 150 */     this.factory = factory;
/* 151 */     this.config = config;
/* 152 */     this.returnNull = returnNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key)
/*     */   {
/* 165 */     return getMessage((Locale)null, key, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object[] args)
/*     */   {
/* 178 */     return getMessage((Locale)null, key, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object arg0)
/*     */   {
/* 191 */     return getMessage((Locale)null, key, arg0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object arg0, Object arg1)
/*     */   {
/* 205 */     return getMessage((Locale)null, key, arg0, arg1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object arg0, Object arg1, Object arg2)
/*     */   {
/* 220 */     return getMessage((Locale)null, key, arg0, arg1, arg2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object arg0, Object arg1, Object arg2, Object arg3)
/*     */   {
/* 241 */     return getMessage((Locale)null, key, arg0, arg1, arg2, arg3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String key, Object arg0, Object arg1, Object arg2, Object arg3, Object arg4)
/*     */   {
/* 263 */     return getMessage((Locale)null, key, arg0, arg1, arg2, arg3, arg4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getMessage(Locale paramLocale, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object[] args)
/*     */   {
/* 294 */     if (locale == null) {
/* 295 */       locale = this.defaultLocale;
/*     */     }
/*     */     
/* 298 */     MessageFormat format = null;
/* 299 */     String formatKey = messageKey(locale, key);
/*     */     
/* 301 */     synchronized (this.formats) {
/* 302 */       format = (MessageFormat)this.formats.get(formatKey);
/* 303 */       if (format == null) {
/* 304 */         String formatString = getMessage(locale, key);
/*     */         
/* 306 */         if (formatString == null) {
/* 307 */           return "???" + formatKey + "???";
/*     */         }
/*     */         
/* 310 */         format = new MessageFormat(escape(formatString));
/* 311 */         format.setLocale(locale);
/* 312 */         this.formats.put(formatKey, format);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 317 */     return format.format(args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object arg0)
/*     */   {
/* 331 */     return getMessage(locale, key, new Object[] { arg0 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object arg0, Object arg1)
/*     */   {
/* 346 */     return getMessage(locale, key, new Object[] { arg0, arg1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object arg0, Object arg1, Object arg2)
/*     */   {
/* 368 */     return getMessage(locale, key, new Object[] { arg0, arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object arg0, Object arg1, Object arg2, Object arg3)
/*     */   {
/* 392 */     return getMessage(locale, key, new Object[] { arg0, arg1, arg2, arg3 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(Locale locale, String key, Object arg0, Object arg1, Object arg2, Object arg3, Object arg4)
/*     */   {
/* 418 */     return getMessage(locale, key, new Object[] { arg0, arg1, arg2, arg3, arg4 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPresent(String key)
/*     */   {
/* 429 */     return isPresent(null, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPresent(Locale locale, String key)
/*     */   {
/* 443 */     String message = getMessage(locale, key);
/*     */     
/* 445 */     if (message == null) {
/* 446 */       return false;
/*     */     }
/* 448 */     if ((message.startsWith("???")) && (message.endsWith("???"))) {
/* 449 */       return false;
/*     */     }
/*     */     
/* 452 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String escape(String string)
/*     */   {
/* 467 */     if ((string == null) || (string.indexOf('\'') < 0)) {
/* 468 */       return string;
/*     */     }
/*     */     
/* 471 */     int n = string.length();
/* 472 */     StringBuffer sb = new StringBuffer(n);
/*     */     
/* 474 */     for (int i = 0; i < n; i++) {
/* 475 */       char ch = string.charAt(i);
/*     */       
/* 477 */       if (ch == '\'') {
/* 478 */         sb.append('\'');
/*     */       }
/*     */       
/* 481 */       sb.append(ch);
/*     */     }
/*     */     
/* 484 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String localeKey(Locale locale)
/*     */   {
/* 496 */     return locale == null ? "" : locale.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String messageKey(Locale locale, String key)
/*     */   {
/* 508 */     return localeKey(locale) + "." + key;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String messageKey(String localeKey, String key)
/*     */   {
/* 521 */     return localeKey + "." + key;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 531 */   protected static MessageResourcesFactory defaultFactory = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized MessageResources getMessageResources(String config)
/*     */   {
/* 541 */     if (defaultFactory == null) {
/* 542 */       defaultFactory = MessageResourcesFactory.createFactory();
/*     */     }
/*     */     
/* 545 */     return defaultFactory.createResources(config);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(String message)
/*     */   {
/* 554 */     log.debug(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(String message, Throwable throwable)
/*     */   {
/* 565 */     log.debug(message, throwable);
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\util\MessageResources.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */