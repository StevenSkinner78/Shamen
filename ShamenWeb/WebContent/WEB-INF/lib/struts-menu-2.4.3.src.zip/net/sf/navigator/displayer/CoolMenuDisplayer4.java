/*     */ package net.sf.navigator.displayer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import net.sf.navigator.menu.MenuComponent;
/*     */ import net.sf.navigator.util.MessageResources;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoolMenuDisplayer4
/*     */   extends MessageResourcesMenuDisplayer
/*     */ {
/*  53 */   private static MessageFormat menuMessage = new MessageFormat(".makeMenu(''{0}'',''{1}'',''{2}'',''{3}'',''{4}'',''{5}'','''','''','''','''','''',''{6}'','''',0,''{7}'',''{8}'',''{9}'');");
/*     */   
/*     */   private static final String TAB = "    ";
/*     */   
/*     */   private static final String SCRIPT_START = "\n<script type=\"text/javascript\">\n<!--";
/*     */   
/*     */   private static final String SCRIPT_END = "//-->\n</script>\n";
/*     */   
/*     */   private static final String END_STATEMENT = ".construct();\n";
/*     */   
/*     */   private String menuId;
/*     */   
/*     */   public void init(PageContext pageContext, MenuDisplayerMapping mapping)
/*     */   {
/*  67 */     super.init(pageContext, mapping);
/*  68 */     this.menuId = ((String)pageContext.getAttribute("menuId"));
/*     */     try
/*     */     {
/*  71 */       this.out.print("\n<script type=\"text/javascript\">\n<!--");
/*     */     } catch (Exception e) {
/*  73 */       this.log.error(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void display(MenuComponent menu)
/*     */     throws JspException, IOException
/*     */   {
/*  82 */     StringBuffer sb = new StringBuffer();
/*  83 */     buildMenuString(menu, sb, isAllowed(menu));
/*  84 */     this.out.print("\n    " + sb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void end(PageContext context)
/*     */   {
/*     */     try
/*     */     {
/*  93 */       this.out.print("    " + getMenuName() + ".construct();\n");
/*  94 */       this.out.print("//-->\n</script>\n");
/*     */     } catch (Exception e) {
/*  96 */       this.log.error(e.getMessage());
/*     */     } finally {
/*  98 */       this.menuId = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void buildMenuString(MenuComponent menu, StringBuffer sb, boolean allowed) {
/* 103 */     if (allowed) {
/* 104 */       sb.append(getMenuName()).append(menuMessage.format(getArgs(menu))).append("\n").append("    ").append("    ");
/*     */       
/* 106 */       MenuComponent[] subMenus = menu.getMenuComponents();
/*     */       
/* 108 */       if (subMenus.length > 0) {
/* 109 */         for (int i = 0; i < subMenus.length; i++) {
/* 110 */           buildMenuString(subMenus[i], sb, isAllowed(subMenus[i]));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String[] getArgs(MenuComponent menu) {
/* 117 */     String[] args = new String[10];
/* 118 */     args[0] = menu.getName();
/* 119 */     args[1] = getParentName(menu);
/* 120 */     args[2] = (menu.getImage() != null ? this.displayStrings.getMessage("cm.image", menu.getImage()) + " " + getMessage(menu.getTitle()) : getMessage(menu.getTitle()));
/*     */     
/*     */ 
/*     */ 
/* 124 */     args[3] = (menu.getUrl() == null ? "" : menu.getUrl());
/* 125 */     args[4] = getTarget(menu);
/* 126 */     args[5] = (menu.getWidth() == null ? "" : menu.getWidth());
/* 127 */     args[6] = (menu.getAlign() == null ? "" : menu.getAlign());
/* 128 */     args[7] = (menu.getOnclick() == null ? "" : menu.getOnclick());
/* 129 */     args[8] = (menu.getOnmouseover() == null ? "" : menu.getOnmouseover());
/*     */     
/* 131 */     args[9] = (menu.getOnmouseout() == null ? "" : menu.getOnmouseout());
/*     */     
/*     */ 
/* 134 */     args[2] = StringUtils.replace(args[2], "\"", "\\\"");
/*     */     
/* 136 */     return args;
/*     */   }
/*     */   
/*     */   protected String getParentName(MenuComponent menu)
/*     */   {
/*     */     String name;
/*     */     String name;
/* 143 */     if (menu.getParent() == null) {
/* 144 */       name = "";
/*     */     } else {
/* 146 */       name = menu.getParent().getName();
/*     */     }
/*     */     
/* 149 */     return name;
/*     */   }
/*     */   
/*     */   protected String getTarget(MenuComponent menu) {
/* 153 */     String theTarget = super.getTarget(menu);
/*     */     
/* 155 */     if (theTarget == null) {
/* 156 */       theTarget = "";
/*     */     }
/*     */     
/* 159 */     return theTarget;
/*     */   }
/*     */   
/*     */   private String getMenuName() {
/* 163 */     return "oCMenu" + (this.menuId != null ? this.menuId : "");
/*     */   }
/*     */ }


/* Location:              D:\API's\struts-menu-2.4.3\struts-menu-2.4.3\struts-menu-2.4.3.jar!\net\sf\navigator\displayer\CoolMenuDisplayer4.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */